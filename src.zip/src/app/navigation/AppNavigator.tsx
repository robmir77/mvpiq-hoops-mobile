import { createNativeStackNavigator } from '@react-navigation/native-stack'
import { useContext } from 'react'
import { Text, View } from 'react-native'
import { AuthContext } from '@/features/auth/context/AuthContext'
import { colors } from '@/shared/theme/colors'
import { RootStackParamList } from './types'

import MainNavigator from './MainNavigator'
import AuthNavigator from './AuthNavigator'
import EditProfileScreen from '@/features/profile/screens/EditProfileScreen'
import EditCvScreen from '@/features/cv/screens/EditCvScreen'
import GoalWizardScreen from '@/features/goals/screens/GoalWizardScreen'
import ChatScreen from '@/features/messaging/screens/ChatScreen'
import NewChatScreen from '@/features/messaging/screens/NewChatScreen'
import MessagingHomeScreen from '@/features/messaging/screens/MessagingHomeScreen'
import NotificationsScreen from '@/features/notifications/screens/NotificationsScreen'
import VideoAnalysisHomeScreen from '@/features/videoAnalysis/screens/VideoAnalysisHomeScreen'
import VideoAnalysisRecorderScreen from '@/features/videoAnalysis/screens/VideoAnalysisRecorderScreen'
import VideoAnalysisProcessingScreen from '@/features/videoAnalysis/screens/VideoAnalysisProcessingScreen'
import HomeScreen from '@/features/home/screens/HomeScreen'
import ProfileScreen from '@/features/profile/screens/ProfileScreen'
import GoalsScreen from '@/features/goals/screens/GoalsScreen'
import CvScreen from '@/features/cv/screens/CvScreen'
import RankingScreen from '@/features/ranking/screens/RankingScreen'
import OnlineUsersScreen from '@/features/users/screens/OnlineUsersScreen'
import AiTrainingNavigator from '@/features/ai-training/navigation/AiTrainingNavigator'
import JournalNavigator from '@/features/journal/navigation/JournalNavigator'
import WorkoutNavigator from '@/features/workouts/navigation/WorkoutNavigator'
import ChecklistTemplatesNavigator from '@/features/checklist-templates/navigation/ChecklistTemplatesNavigator'
import ScoutingScreen from '@/features/scouting/screens/ScoutingScreen'
import StatsScreen from '@/features/workouts/screens/StatsScreen'
import BadgesScreen from '@/features/badges/screens/BadgesScreen'
import TrainerClientsScreen from '@/features/trainer/screens/TrainerClientsScreen'
import TrainingScreen from '@/features/training/screens/TrainingScreen'
import ExercisesScreen from '@/features/exercises/screens/ExercisesScreen'
import SubscriptionsScreen from '@/features/subscriptions/screens/SubscriptionsScreen'
import SettingsScreen from '@/features/profile/screens/SettingsScreen'

// Placeholder components for screens not yet implemented
const makePlaceholder = (label: string): React.FC => {
    const Screen: React.FC = () => (
        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: colors.background }}>
            <Text style={{ color: colors.textPrimary, fontSize: 18, fontWeight: 'bold' }}>{label}</Text>
            <Text style={{ color: colors.textSecondary, fontSize: 13, marginTop: 6 }}>Coming Soon</Text>
        </View>
    )
    Screen.displayName = `Placeholder_${label}`
    return Screen
}

const CreatorContentScreen = makePlaceholder('Contenuti')
const CreatorTemplatesScreen = makePlaceholder('Template')
const CreatorAnalyticsScreen = makePlaceholder('Analytics')
const MediaScreen = makePlaceholder('Media')
const VideoAnalysisScreen = makePlaceholder('Analisi Video')
const LiveShotTrackingScreen = makePlaceholder('Conteggio Live')
const ComingSoonScreen = makePlaceholder('Coming Soon')

const Stack = createNativeStackNavigator<RootStackParamList>()


export default function AppNavigator() {
    const auth = useContext(AuthContext)

    if (!auth) return null

    const { user } = auth

    return (
        <Stack.Navigator>
            {user ? (
                <>
                    <Stack.Screen
                        name="Main"
                        component={MainNavigator}
                        options={{ headerShown: false }}
                    />

                    <Stack.Screen
                        name="EditProfile"
                        component={EditProfileScreen}
                        options={{
                            title: 'Modifica Profilo',
                            headerStyle: { backgroundColor: '#0b0f1a' },
                            headerTintColor: '#fff',
                        }}
                    />

                    <Stack.Screen
                        name="EditCv"
                        component={EditCvScreen}
                        options={{
                            title: 'Curriculum Sportivo',
                            headerStyle: { backgroundColor: '#0b0f1a' },
                            headerTintColor: '#fff',
                        }}
                    />

                    <Stack.Screen
                        name="GoalWizard"
                        component={GoalWizardScreen}
                        options={{
                            title: 'Imposta i tuoi obiettivi',
                            headerStyle: { backgroundColor: '#0b0f1a' },
                            headerTintColor: '#fff',
                            headerShown: true,
                        }}
                    />

                    <Stack.Screen
                        name="ChatScreen"
                        component={ChatScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="NewChat"
                        component={NewChatScreen}
                        options={{
                            title: 'Nuova conversazione',
                            headerStyle: { backgroundColor: '#0b0f1a' },
                            headerTintColor: '#fff',
                        }}
                    />

                    <Stack.Screen
                        name="messages"
                        component={MessagingHomeScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="notifications"
                        component={NotificationsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="home"
                        component={HomeScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="profile"
                        component={ProfileScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_profile"
                        component={ProfileScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_goals"
                        component={GoalsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_cv"
                        component={CvScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="scout_rankings"
                        component={RankingScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="admin_users"
                        component={OnlineUsersScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_journal"
                        component={JournalNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_training"
                        component={AiTrainingNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_workouts"
                        component={WorkoutNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="ai_training_tools"
                        component={AiTrainingNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="trainer_ai"
                        component={AiTrainingNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="admin_checklist"
                        component={ChecklistTemplatesNavigator}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_stats"
                        component={StatsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="player_media"
                        component={MediaScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="scout_search"
                        component={ScoutingScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="scout_reports"
                        component={ComingSoonScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="trainer_programs"
                        component={TrainingScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="trainer_clients"
                        component={TrainerClientsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="trainer_exercises"
                        component={ExercisesScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="creator_content"
                        component={CreatorContentScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="creator_templates"
                        component={CreatorTemplatesScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="creator_analytics"
                        component={CreatorAnalyticsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="admin_subscriptions"
                        component={SubscriptionsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="admin_gamification"
                        component={BadgesScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="admin_notifications"
                        component={NotificationsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="settings"
                        component={SettingsScreen}
                        options={{
                            headerShown: false,
                        }}
                    />


                    <Stack.Screen
                        name="video_analysis"
                        component={VideoAnalysisHomeScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="VideoRecorder"
                        component={VideoAnalysisRecorderScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="VideoProcessing"
                        component={VideoAnalysisProcessingScreen}
                        options={{
                            headerShown: false,
                        }}
                    />

                    <Stack.Screen
                        name="live_shot_tracking"
                        component={LiveShotTrackingScreen}
                        options={{
                            headerShown: false,
                        }}
                    />
                </>
            ) : (
                <Stack.Screen
                    name="Auth"
                    component={AuthNavigator}
                    options={{ headerShown: false }}
                />
            )}
        </Stack.Navigator>
    )
}
