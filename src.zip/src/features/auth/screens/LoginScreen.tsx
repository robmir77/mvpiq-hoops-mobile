// C:\MVPiQHoopsMobile\src\features\auth\screens\LoginScreen.tsx
import React, { useState, useContext } from 'react';
import {
    View,
    Text,
    TextInput,
    StyleSheet,
    Image,
    KeyboardAvoidingView,
    Platform,
    TouchableOpacity,
    ActivityIndicator,
    ScrollView,
} from 'react-native';
import { login } from '../api/auth';
import { saveAuth } from '@/shared/storage/authStorage';
import { AuthContext } from '@/features/auth/context/AuthContext';
import { useGlobalAlert } from '@/shared/context/AlertContext';
import { NativeStackScreenProps } from '@react-navigation/native-stack';
import { AuthStackParamList } from '@/app/navigation/types';
import { globalStyles } from '@/shared/theme/globalStyles';

type Props = NativeStackScreenProps<AuthStackParamList, 'Login'>;

const LoginScreen = ({ navigation }: Props) => {
    const auth = useContext(AuthContext);
    if (!auth) return null;

    const { setUser } = auth;
    const { showError } = useGlobalAlert();

    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);
    const [showPassword, setShowPassword] = useState(false);

    const handleLogin = async () => {
        if (!email || !password) {
            showError('Errore', 'Compila tutti i campi');
            return;
        }

        setLoading(true);

        try {
            const userData = await login(email, password);
            const token = userData?.token;

            if (!token) {
                throw new Error('Token non ricevuto dal server');
            }

            await saveAuth(token, userData);
            setUser(userData);
        } catch (error: any) {
            showError(
                'Errore',
                error?.message || 'Email o password non corretti'
            );
        } finally {
            setLoading(false);
        }
    };

    return (
        <KeyboardAvoidingView
            style={{ flex: 1, backgroundColor: '#0F172A' }}
            behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        >
            <ScrollView
                contentContainerStyle={styles.container}
                keyboardShouldPersistTaps="handled"
            >
                <Image
                    source={require('../../../../assets/logo.png')}
                    style={styles.logo}
                    resizeMode="contain"
                />

                <Text style={styles.title}>Bentornato</Text>
                <Text style={styles.subtitle}>
                    Accedi per continuare la tua crescita
                </Text>

                <View style={styles.card}>
                    <View style={styles.inputContainer}>
                        <TextInput
                            style={styles.inputWithIcon}
                            placeholder="Email"
                            placeholderTextColor="#94A3B8"
                            value={email}
                            onChangeText={setEmail}
                            autoCapitalize="none"
                            keyboardType="email-address"
                        />
                    </View>

                    <View style={styles.inputContainer}>
                        <TextInput
                            style={styles.inputWithIcon}
                            placeholder="Password"
                            placeholderTextColor="#94A3B8"
                            value={password}
                            onChangeText={setPassword}
                            secureTextEntry={!showPassword}
                        />
                        <TouchableOpacity
                            style={styles.eyeIcon}
                            onPress={() => setShowPassword(!showPassword)}
                        >
                            <Text style={styles.eyeText}>
                                {showPassword ? '🙈' : '👁️'}
                            </Text>
                        </TouchableOpacity>
                    </View>

                    <TouchableOpacity
                        style={globalStyles.button}
                        onPress={handleLogin}
                        disabled={loading}
                    >
                        {loading ? (
                            <ActivityIndicator color="#fff" />
                        ) : (
                            <Text style={globalStyles.buttonText}>Accedi</Text>
                        )}
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={styles.linkButton}
                        onPress={() => navigation.navigate('Register')}
                    >
                        <Text style={styles.linkText}>
                            Non hai un account? Creane uno
                        </Text>
                    </TouchableOpacity>
                </View>
            </ScrollView>
        </KeyboardAvoidingView>
    );
};

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        justifyContent: 'center',
        padding: 24,
    },
    logo: {
        width: 120,
        height: 120,
        alignSelf: 'center',
        marginBottom: 30,
    },
    title: {
        fontSize: 28,
        fontWeight: '700',
        color: '#FFFFFF',
        textAlign: 'center',
    },
    subtitle: {
        fontSize: 14,
        color: '#94A3B8',
        textAlign: 'center',
        marginBottom: 30,
    },
    card: {
        backgroundColor: '#1E293B',
        padding: 24,
        borderRadius: 20,
    },
    input: {
        backgroundColor: '#334155',
        borderRadius: 12,
        padding: 14,
        color: '#FFFFFF',
        marginBottom: 16,
    },
    inputContainer: {
        position: 'relative',
        marginBottom: 16,
    },
    inputWithIcon: {
        backgroundColor: '#334155',
        borderRadius: 12,
        padding: 14,
        color: '#FFFFFF',
        paddingRight: 45,
    },
    eyeIcon: {
        position: 'absolute',
        right: 15,
        top: 14,
        padding: 5,
    },
    eyeText: {
        fontSize: 16,
        color: '#94A3B8',
    },
        linkButton: {
        marginTop: 20,
        alignItems: 'center',
    },
    linkText: {
        color: '#F97316',
        fontSize: 14,
        fontWeight: '500',
    },
});

export default LoginScreen;