import React, { useState, useContext } from 'react'
import { View, Text, StyleSheet, TouchableOpacity, FlatList, RefreshControl } from 'react-native'
import { globalStyles } from '@/shared/theme/globalStyles'
import { AuthContext } from '@/features/auth/context/AuthContext'
import { useJournalEntries } from '../hooks/useJournalEntries'
import { useQueryClient } from '@tanstack/react-query'
import { deleteJournalEntry } from '../api/journal.api'
import { useCustomAlert, CustomAlert } from '@/shared/components/CustomAlert'

type FilterType = 'ALL' | 'MATCH' | 'TRAINING'

export default function JournalHomeScreen({ navigation }: any) {
    const auth = useContext(AuthContext)
    const [filter, setFilter] = useState<FilterType>('ALL')
    const { user } = auth || {}

    const entryTypeFilter = filter === 'ALL' ? undefined : filter
    const queryClient = useQueryClient()

    const { data: entries, isLoading, error } = useJournalEntries(user?.id || '', entryTypeFilter)

    const [refreshing, setRefreshing] = useState(false)
    const [deletingId, setDeletingId] = useState<string | null>(null)
    const { alert, showWarning, showError, showSuccess } = useCustomAlert()

    const onRefresh = async () => {
        setRefreshing(true)
        await queryClient.invalidateQueries({ queryKey: ['journalEntries'] })
        setRefreshing(false)
    }

    const renderFilterButton = (type: FilterType, label: string) => (
        <TouchableOpacity
            style={[
                styles.filterButton,
                filter === type && styles.filterButtonActive
            ]}
            onPress={() => setFilter(type)}
        >
            <Text style={[
                styles.filterButtonText,
                filter === type && styles.filterButtonTextActive
            ]}>
                {label}
            </Text>
        </TouchableOpacity>
    )

    // Get first checklist value for preview
    const getFirstValue = (item: any) => {
        if (!item.checklists || item.checklists.length === 0) return null

        const checklist = item.checklists[0]
        if (!checklist.answers || checklist.answers.length === 0) return null

        const answer = checklist.answers[0]
        const templateItem = checklist.template?.items?.find((i: any) => i.id === answer.itemId)

        let value = '-'
        if (templateItem?.dataType === 'BOOLEAN') {
            value = answer.booleanValue ? 'Sì' : 'No'
        } else if (templateItem?.dataType === 'SELECT' || templateItem?.dataType === 'MULTI_SELECT') {
            const option = templateItem?.options?.find((o: any) => o.valueCode === answer.selectValue)
            value = option?.valueLabel || answer.selectValue || '-'
        } else if (templateItem?.dataType === 'NUMBER') {
            value = answer.numberValue?.toString() || '-'
        } else if (templateItem?.dataType === 'DATE') {
            value = answer.dateValue || '-'
        } else {
            value = answer.textValue || '-'
        }

        return { label: templateItem?.label || 'Valore', value }
    }

    const handleDelete = (entryId: string) => {
        showWarning(
            'Elimina diario',
            'Sei sicuro di voler eliminare questo diario? L\'azione non è reversibile.',
            async () => {
                if (!user?.id) return
                setDeletingId(entryId)
                try {
                    await deleteJournalEntry(user.id, entryId)
                    showSuccess('Eliminato', 'Diario eliminato con successo')
                    queryClient.invalidateQueries({ queryKey: ['journalEntries'] })
                } catch (error) {
                    showError('Errore', 'Impossibile eliminare il diario')
                } finally {
                    setDeletingId(null)
                }
            },
            () => {}
        )
    }

    const renderEntryCard = ({ item }: any) => {
        const firstValue = getFirstValue(item)
        const isDeleting = deletingId === item.id

        return (
            <View style={styles.entryCard}>
                <TouchableOpacity
                    style={styles.cardContent}
                    onPress={() => navigation.navigate('JournalDetail', { id: item.id })}
                    disabled={isDeleting}
                >
                    <View style={styles.cardHeader}>
                        <Text style={styles.entryDate}>
                            {item.entryDate ? new Date(item.entryDate).toLocaleDateString('it-IT', {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                            }) : 'Data non disponibile'}
                        </Text>
                        <Text style={styles.entryType}>
                            {item.entryType === 'MATCH' ? '⚽ Partita' : '🏋️ Allenamento'}
                        </Text>
                    </View>
                    <Text style={styles.entryTitle}>
                        {item.entryType === 'MATCH' ? 'Diario Partita' : 'Diario Allenamento'}
                        {firstValue && ` · ${firstValue.value}`}
                    </Text>
                    <Text style={styles.viewDetails}>Vedi dettagli →</Text>
                </TouchableOpacity>
                <TouchableOpacity
                    style={styles.deleteButton}
                    onPress={() => handleDelete(item.id)}
                    disabled={isDeleting}
                >
                    <Text style={styles.deleteButtonText}>
                        {isDeleting ? '⏳' : '🗑️'}
                    </Text>
                </TouchableOpacity>
            </View>
        )
    }

    const renderEmptyState = () => (
        <View style={styles.emptyState}>
            <Text style={styles.emptyStateIcon}>📝</Text>
            <Text style={styles.emptyStateTitle}>Nessun diario creato</Text>
            <Text style={styles.emptyStateText}>
                Crea il tuo primo diario partita o allenamento
            </Text>
        </View>
    )

    return (
        <View style={styles.container}>
            <Text style={styles.title}>Diario</Text>

            {/* Pulsanti Crea */}
            <View style={styles.createButtons}>
                <TouchableOpacity
                    style={[globalStyles.button, styles.createButton]}
                    onPress={() =>
                        navigation.navigate('JournalCreate', { entryType: 'MATCH' })
                    }
                >
                    <Text style={globalStyles.buttonText}>+ Partita</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[globalStyles.button, styles.createButton, styles.trainingButton]}
                    onPress={() =>
                        navigation.navigate('JournalCreate', { entryType: 'TRAINING' })
                    }
                >
                    <Text style={globalStyles.buttonText}>+ Allenamento</Text>
                </TouchableOpacity>
            </View>

            {/* Filtri */}
            <View style={styles.filterContainer}>
                {renderFilterButton('ALL', 'Tutte')}
                {renderFilterButton('MATCH', 'Partite')}
                {renderFilterButton('TRAINING', 'Allenamenti')}
            </View>

            {/* Lista Storico */}
            {isLoading ? (
                <View style={styles.loadingContainer}>
                    <Text style={styles.loadingText}>Caricamento...</Text>
                </View>
            ) : error ? (
                <View style={styles.errorContainer}>
                    <Text style={styles.errorText}>Errore nel caricamento</Text>
                </View>
            ) : (
                <FlatList
                    data={entries || []}
                    renderItem={renderEntryCard}
                    keyExtractor={(item) => item.id}
                    contentContainerStyle={entries?.length === 0 ? styles.emptyList : undefined}
                    ListEmptyComponent={renderEmptyState}
                    showsVerticalScrollIndicator={false}
                    refreshControl={
                        <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
                    }
                />
            )}
            <CustomAlert {...alert} />
        </View>
    )
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#0b0f1a',
        padding: 20,
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: 'white',
        marginBottom: 15,
    },
    filterContainer: {
        flexDirection: 'row',
        marginBottom: 15,
        gap: 8,
    },
    filterButton: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 15,
        borderRadius: 8,
        backgroundColor: '#1a1a1a',
        borderWidth: 1,
        borderColor: '#2a2a2a',
        alignItems: 'center',
    },
    filterButtonActive: {
        backgroundColor: '#ff8c00',
        borderColor: '#ff8c00',
    },
    filterButtonText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#888',
    },
    filterButtonTextActive: {
        color: '#fff',
    },
    createButtons: {
        flexDirection: 'row',
        gap: 10,
        marginBottom: 15,
    },
    createButton: {
        flex: 1,
    },
    trainingButton: {
        backgroundColor: '#f97316',
    },
    entryCard: {
        backgroundColor: '#121826',
        borderRadius: 12,
        padding: 15,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#2a2a2a',
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 8,
    },
    entryDate: {
        fontSize: 12,
        color: '#888',
        fontWeight: '500',
    },
    entryType: {
        fontSize: 12,
        color: '#ff8c00',
        fontWeight: '600',
    },
    entryTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 6,
    },
    entrySummary: {
        fontSize: 14,
        color: '#aaa',
        marginBottom: 8,
        lineHeight: 20,
    },
    viewDetails: {
        fontSize: 13,
        color: '#ff8c00',
        fontWeight: '600',
    },
    cardContent: {
        flex: 1,
    },
    deleteButton: {
        position: 'absolute',
        right: 10,
        bottom: 15,
        width: 30,
        height: 30,
        justifyContent: 'center',
        alignItems: 'center',
    },
    deleteButtonText: {
        fontSize: 16,
    },
    emptyState: {
        alignItems: 'center',
        paddingVertical: 40,
    },
    emptyStateIcon: {
        fontSize: 48,
        marginBottom: 15,
    },
    emptyStateTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#fff',
        marginBottom: 8,
    },
    emptyStateText: {
        fontSize: 14,
        color: '#888',
        textAlign: 'center',
    },
    emptyList: {
        flexGrow: 1,
    },
    loadingContainer: {
        alignItems: 'center',
        paddingVertical: 40,
    },
    loadingText: {
        color: '#888',
        fontSize: 14,
    },
    errorContainer: {
        alignItems: 'center',
        paddingVertical: 40,
    },
    errorText: {
        color: '#ef4444',
        fontSize: 14,
    },
})