import apiClient from '@/shared/api/apiClient'

import {
    VideoAnalysisType,
    VideoAnalysisSession,
    VideoAnalysisResult,
} from '../types/videoAnalysis.types'


export const getAnalysisTypes = async (): Promise<VideoAnalysisType[]> => {

    const response = await apiClient.get<VideoAnalysisType[]>(
        '/analysis/types'
    )

    return response.data
}

export const createAnalysisSession = async (data: {
    analysisCode: string
    videoUrl: string
    videoSeconds: number
    videoSizeMb: number
}) => {

    const response = await apiClient.post(
        "/analysis/sessions",
        data
    )

    return response.data
}


export const analyzeVideo = async (data: {
    sessionId: string
    videoUrl: string
    analysisType: string
}): Promise<{ analysisId: string; status: string }> => {
    const response = await apiClient.post(
        "/analysis/analyze",
        data
    )

    return response.data
}

export const getAnalysisResult = async (
    sessionId: string
): Promise<VideoAnalysisResult> => {

    const response = await apiClient.get<VideoAnalysisResult>(
        `/analysis/sessions/${sessionId}/result`
    )

    return response.data
}