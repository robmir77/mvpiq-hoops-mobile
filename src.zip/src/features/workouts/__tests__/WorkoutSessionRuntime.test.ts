import { WorkoutSessionRuntime } from '../runtime/WorkoutSessionRuntime'

// Mock the queue to avoid async operations in tests
jest.mock('../services/workoutAsyncQueue', () => ({
  createWorkoutQueue: jest.fn().mockResolvedValue({
    enqueueCritical: jest.fn().mockResolvedValue(true),
    enqueueTelemetry: jest.fn(),
    flushCriticalOnly: jest.fn(),
    flushTelemetryOnly: jest.fn(),
    shutdown: jest.fn(),
    criticalSize: 0,
    telemetrySize: 0,
    telemetryDropped: 0,
    criticalOverflow: 0,
    getQueueMetrics: jest.fn().mockReturnValue({
      telemetry: { pending: 0, dropped: 0 },
      critical: { pending: 0, overflow: 0 },
    }),
  }),
}))

describe('WorkoutSessionRuntime', () => {
  let runtime: WorkoutSessionRuntime
  const mockSessionId = 'test-session-123'
  const mockUserId = 'user-456'

  beforeEach(() => {
    jest.useFakeTimers()
    jest.clearAllMocks()
    runtime = new WorkoutSessionRuntime(
      { sessionId: mockSessionId, userId: mockUserId },
      {
        onSessionStateChanged: jest.fn(),
        onShotDetected: jest.fn(),
        onTelemetryUpdate: jest.fn(),
        onError: jest.fn(),
      }
    )
  })

  afterEach(() => {
    jest.useRealTimers()
  })

  describe('initial state', () => {
    it('should start in IDLE state', () => {
      expect(runtime.getState()).toBe('IDLE')
    })

    it('should have zero metrics initially', () => {
      const metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(0)
      expect(metrics.madeShots).toBe(0)
      expect(metrics.sessionDuration).toBe(0)
    })
  })

  describe('state machine transitions', () => {
    it('should transition from IDLE to STARTING on start()', async () => {
      await runtime.start()
      expect(runtime.getState()).toBe('ACTIVE') // Goes through STARTING to ACTIVE
    })

    it('should transition from ACTIVE to PAUSED on pause()', async () => {
      await runtime.start()
      await runtime.pause()
      expect(runtime.getState()).toBe('PAUSED')
    })

    it('should transition from PAUSED to ACTIVE on resume()', async () => {
      await runtime.start()
      await runtime.pause()
      await runtime.resume()
      expect(runtime.getState()).toBe('ACTIVE')
    })

    it('should transition from ACTIVE to STOPPING on stop()', async () => {
      await runtime.start()
      await runtime.stop()
      expect(runtime.getState()).toBe('COMPLETED') // Goes through STOPPING -> SYNCING -> COMPLETED
    })

    it('should transition from PAUSED to STOPPING on stop()', async () => {
      await runtime.start()
      await runtime.pause()
      await runtime.stop()
      expect(runtime.getState()).toBe('COMPLETED')
    })

    it('should call onSessionStateChanged callback on each transition', async () => {
      const callback = jest.fn()
      const runtimeWithCallback = new WorkoutSessionRuntime(
        { sessionId: mockSessionId, userId: mockUserId },
        { onSessionStateChanged: callback }
      )

      await runtimeWithCallback.start()
      expect(callback).toHaveBeenCalledWith('STARTING')
      expect(callback).toHaveBeenCalledWith('ACTIVE')
      expect(callback).toHaveBeenCalledTimes(2)
    })
  })

  describe('illegal transitions', () => {
    it('should throw when starting from ACTIVE state', async () => {
      await runtime.start()
      await expect(runtime.start()).rejects.toThrow('Cannot start session from state: ACTIVE')
    })

    it('should throw when pausing from IDLE state', async () => {
      await expect(runtime.pause()).rejects.toThrow('Cannot pause session from state: IDLE')
    })

    it('should throw when resuming from IDLE state', async () => {
      await expect(runtime.resume()).rejects.toThrow('Cannot resume session from state: IDLE')
    })

    it('should allow stopping from IDLE state (user cancels before starting)', async () => {
      await expect(runtime.stop()).resolves.not.toThrow()
      expect(runtime.getState()).toBe('COMPLETED')
    })

    it('should throw when pausing from COMPLETED state', async () => {
      await runtime.start()
      await runtime.stop()
      await expect(runtime.pause()).rejects.toThrow('Cannot pause session from state: COMPLETED')
    })
  })

  describe('manual shot registration', () => {
    it('should register MADE shot and update metrics', async () => {
      // Set up mock queue
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        flushCriticalOnly: jest.fn(),
        flushTelemetryOnly: jest.fn(),
        shutdown: jest.fn(),
        criticalSize: 0,
        telemetrySize: 0,
        telemetryDropped: 0,
        criticalOverflow: 0,
        getQueueMetrics: jest.fn().mockReturnValue({
          telemetry: { pending: 0, dropped: 0 },
          critical: { pending: 0, overflow: 0 },
        }),
      }
      runtime.setWorkoutQueue(mockQueue)

      await runtime.start()
      await runtime.registerManualShot('MADE')

      const metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(1)
      expect(metrics.madeShots).toBe(1)
    })

    it('should register MISS shot and update metrics', async () => {
      // Set up mock queue
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        flushCriticalOnly: jest.fn(),
        flushTelemetryOnly: jest.fn(),
        shutdown: jest.fn(),
        criticalSize: 0,
        telemetrySize: 0,
        telemetryDropped: 0,
        criticalOverflow: 0,
        getQueueMetrics: jest.fn().mockReturnValue({
          telemetry: { pending: 0, dropped: 0 },
          critical: { pending: 0, overflow: 0 },
        }),
      }
      runtime.setWorkoutQueue(mockQueue)

      await runtime.start()
      await runtime.registerManualShot('MISS')

      const metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(1)
      expect(metrics.madeShots).toBe(0)
    })

    it('should call onShotDetected callback', async () => {
      const callback = jest.fn()
      const runtimeWithCallback = new WorkoutSessionRuntime(
        { sessionId: mockSessionId, userId: mockUserId },
        { onShotDetected: callback }
      )

      // Set up mock queue
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        flushCriticalOnly: jest.fn(),
        flushTelemetryOnly: jest.fn(),
        shutdown: jest.fn(),
        criticalSize: 0,
        telemetrySize: 0,
        telemetryDropped: 0,
        criticalOverflow: 0,
        getQueueMetrics: jest.fn().mockReturnValue({
          telemetry: { pending: 0, dropped: 0 },
          critical: { pending: 0, overflow: 0 },
        }),
      }
      runtimeWithCallback.setWorkoutQueue(mockQueue)

      await runtimeWithCallback.start()
      await runtimeWithCallback.registerManualShot('MADE')

      expect(callback).toHaveBeenCalledWith('MADE')
    })

    it('should throw when registering shot from non-ACTIVE state', async () => {
      await expect(runtime.registerManualShot('MADE')).rejects.toThrow(
        'Cannot register shot from state: IDLE'
      )
    })

    it('should throw when registering shot from PAUSED state', async () => {
      await runtime.start()
      await runtime.pause()
      await expect(runtime.registerManualShot('MADE')).rejects.toThrow(
        'Cannot register shot from state: PAUSED'
      )
    })
  })

  describe('critical event queuing', () => {
    it('should enqueue critical event when queue is set', async () => {
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        shutdown: jest.fn().mockResolvedValue(undefined),
      }

      runtime.setWorkoutQueue(mockQueue)
      await runtime.start()

      await runtime.enqueueCritical({
        type: 'SHOT',
        sessionId: mockSessionId,
        userId: mockUserId,
        payload: { timestampMs: Date.now(), shotResult: 'MADE' },
      })

      expect(mockQueue.enqueueCritical).toHaveBeenCalled()
    })

    it('should return false and warn when queue is not set', async () => {
      const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation()

      const result = await runtime.enqueueCritical({
        type: 'SHOT',
        sessionId: mockSessionId,
        userId: mockUserId,
      })

      expect(result).toBe(false)
      expect(consoleWarnSpy).toHaveBeenCalledWith('[WorkoutSessionRuntime] Queue not set, cannot enqueue critical event')

      consoleWarnSpy.mockRestore()
    })
  })

  describe('telemetry queuing', () => {
    it('should enqueue telemetry when queue is set', async () => {
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        shutdown: jest.fn().mockResolvedValue(undefined),
      }

      runtime.setWorkoutQueue(mockQueue)
      await runtime.start()

      runtime.enqueueTelemetry({
        frameTimestamp: Date.now(),
        ballX: 0.5,
        ballY: 0.5,
      })

      expect(mockQueue.enqueueTelemetry).toHaveBeenCalled()
    })

    it('should warn when queue is not set', () => {
      const consoleWarnSpy = jest.spyOn(console, 'warn').mockImplementation()

      runtime.enqueueTelemetry({
        frameTimestamp: Date.now(),
      })

      expect(consoleWarnSpy).toHaveBeenCalledWith('[WorkoutSessionRuntime] Queue not set, cannot enqueue telemetry')

      consoleWarnSpy.mockRestore()
    })
  })

  describe('subsystem connections', () => {
    it('should set vision engine', () => {
      const mockVisionEngine = {
        start: jest.fn(),
        stop: jest.fn(),
        processFrame: jest.fn(),
        getCurrentResults: jest.fn(),
        setBallDetectionEnabled: jest.fn(),
        setPlayerDetectionEnabled: jest.fn(),
        setRimDetectionEnabled: jest.fn(),
        setPoseDetectionEnabled: jest.fn(),
        isReady: jest.fn(),
      }

      runtime.setVisionEngine(mockVisionEngine)
      // No getter for vision engine, but it should be stored
    })

    it('should set tracking engine', () => {
      const mockTrackingEngine = {
        processFrame: jest.fn(),
        resetShot: jest.fn(),
        resetAll: jest.fn(),
        getState: jest.fn(),
        getComparisonStats: jest.fn(),
        getCurrentPlayerPosition: jest.fn(),
      }

      runtime.setTrackingEngine(mockTrackingEngine)
      expect(runtime.getTrackingEngine()).toBe(mockTrackingEngine)
    })

    it('should set shot detection engine', () => {
      const mockShotEngine = {
        processFrame: jest.fn(),
        resetShot: jest.fn(),
        resetAll: jest.fn(),
      }

      runtime.setShotDetectionEngine(mockShotEngine)
      // No getter for shot engine, but it should be stored
    })

    it('should set telemetry sampler', () => {
      const mockSampler = {
        shouldSample: jest.fn(),
        reset: jest.fn(),
        getLastSampleTime: jest.fn(),
        setSampleInterval: jest.fn(),
      }

      runtime.setTelemetrySampler(mockSampler)
      // No getter for telemetry sampler, but it should be stored
    })

    it('should set workout queue', () => {
      const mockQueue = {
        enqueueCritical: jest.fn(),
        enqueueTelemetry: jest.fn(),
        shutdown: jest.fn(),
      }

      runtime.setWorkoutQueue(mockQueue)
      // No getter for workout queue, but it should be stored
    })
  })

  describe('vision engine lifecycle', () => {
    const createMockVisionEngine = () => ({
      start: jest.fn(),
      stop: jest.fn(),
      processFrame: jest.fn(),
      getCurrentResults: jest.fn(),
      setBallDetectionEnabled: jest.fn(),
      setPlayerDetectionEnabled: jest.fn(),
      setRimDetectionEnabled: jest.fn(),
      setPoseDetectionEnabled: jest.fn(),
      isReady: jest.fn(),
    })

    it('should not call vision engine start/stop (architectural change - vision runs independently)', async () => {
      const mockVisionEngine = createMockVisionEngine()

      runtime.setVisionEngine(mockVisionEngine)
      await runtime.start()
      await runtime.pause()
      await runtime.resume()
      await runtime.stop()

      // Vision engine lifecycle is managed externally (useShotTracker), not by Runtime
      expect(mockVisionEngine.start).not.toHaveBeenCalled()
      expect(mockVisionEngine.stop).not.toHaveBeenCalled()
    })

    it('should not crash when vision engine is not set', async () => {
      await runtime.start()
      await runtime.pause()
      await runtime.resume()
      await runtime.stop()

      expect(runtime.getState()).toBe('COMPLETED')
    })
  })

  describe('queue shutdown', () => {
    it('should call queue shutdown on stop', async () => {
      const mockQueue = {
        enqueueCritical: jest.fn().mockResolvedValue(true),
        enqueueTelemetry: jest.fn(),
        shutdown: jest.fn().mockResolvedValue(undefined),
      }

      runtime.setWorkoutQueue(mockQueue)
      await runtime.start()
      await runtime.stop()

      expect(mockQueue.shutdown).toHaveBeenCalled()
    })

    it('should not crash when queue is not set on stop', async () => {
      await runtime.start()
      await runtime.stop()

      expect(runtime.getState()).toBe('COMPLETED')
    })
  })

  describe('session duration tracking', () => {
    it('should track session duration when active', async () => {
      await runtime.start()
      jest.advanceTimersByTime(1000)

      const metrics = runtime.getMetrics()
      expect(metrics.sessionDuration).toBe(1000)
    })

    it('should stop tracking duration when paused', async () => {
      await runtime.start()
      jest.advanceTimersByTime(1000)
      await runtime.pause()
      jest.advanceTimersByTime(1000)

      const metrics = runtime.getMetrics()
      // Duration should not increase while paused (implementation may vary)
      expect(metrics.sessionDuration).toBeGreaterThanOrEqual(1000)
    })

    it('should resume tracking duration when resumed', async () => {
      await runtime.start()
      jest.advanceTimersByTime(1000)
      await runtime.pause()
      await runtime.resume()
      jest.advanceTimersByTime(1000)

      const metrics = runtime.getMetrics()
      expect(metrics.sessionDuration).toBeGreaterThanOrEqual(2000)
    })

    it('should stop tracking duration when stopped', async () => {
      await runtime.start()
      jest.advanceTimersByTime(1000)
      await runtime.stop()
      jest.advanceTimersByTime(1000)

      const metrics = runtime.getMetrics()
      // Duration should not increase after stop
      expect(metrics.sessionDuration).toBe(1000)
    })
  })

  describe('error handling', () => {
    it('should transition to ERROR state on initialization error', async () => {
      const mockQueue = {
        enqueueCritical: jest.fn().mockRejectedValue(new Error('Queue error')),
        enqueueTelemetry: jest.fn(),
        shutdown: jest.fn().mockResolvedValue(undefined),
      }

      runtime.setWorkoutQueue(mockQueue)
      // The error will occur during queue initialization in start()
      // This test may need adjustment based on actual error handling implementation
    })

    it('should call onError callback on error', async () => {
      const errorCallback = jest.fn()
      const runtimeWithError = new WorkoutSessionRuntime(
        { sessionId: mockSessionId, userId: mockUserId },
        { onError: errorCallback }
      )

      // Force an error by stopping from invalid state
      try {
        await runtimeWithError.stop()
      } catch (e) {
        // Expected to throw
      }

      // Error callback should be called if state transition fails
      // This may need adjustment based on actual error handling
    })
  })

  describe('processFrame - frame processing', () => {
    const createMockVisionEngine = () => ({
      start: jest.fn(),
      stop: jest.fn(),
      processFrame: jest.fn().mockReturnValue({
        ball: null,
        player: null,
        rim: null,
        pose: null,
        observationTimestamps: {},
      }),
      getCurrentResults: jest.fn().mockReturnValue({
        ball: null,
        player: null,
        rim: null,
        pose: null,
        poseTimestamp: null,
      }),
      setBallDetectionEnabled: jest.fn(),
      setPlayerDetectionEnabled: jest.fn(),
      setRimDetectionEnabled: jest.fn(),
      setPoseDetectionEnabled: jest.fn(),
      isReady: jest.fn(),
    })

    const createMockTrackingEngine = () => ({
      processFrame: jest.fn().mockReturnValue({
        ballPosition: null,
        ballPositionRaw: null,
        ballVelocity: null,
        hoopPosition: null,
        confidence: null,
        inFlight: false,
        shotDetected: false,
        shotResult: null,
        trajectory: [],
      }),
      resetShot: jest.fn(),
      resetAll: jest.fn(),
      getState: jest.fn(),
      getComparisonStats: jest.fn(),
      getCurrentPlayerPosition: jest.fn(),
    })

    const createMockQueue = () => ({
      enqueueCritical: jest.fn().mockResolvedValue(true),
      enqueueTelemetry: jest.fn(),
      flushCriticalOnly: jest.fn(),
      flushTelemetryOnly: jest.fn(),
      shutdown: jest.fn().mockResolvedValue(undefined),
      criticalSize: 0,
      telemetrySize: 0,
      telemetryDropped: 0,
      criticalOverflow: 0,
      getQueueMetrics: jest.fn().mockReturnValue({
        telemetry: { pending: 0, dropped: 0 },
        critical: { pending: 0, overflow: 0 },
      }),
    })

    beforeEach(() => {
      const mockVisionEngine = createMockVisionEngine()
      const mockTrackingEngine = createMockTrackingEngine()
      const mockQueue = createMockQueue()

      runtime.setVisionEngine(mockVisionEngine)
      runtime.setTrackingEngine(mockTrackingEngine)
      runtime.setWorkoutQueue(mockQueue)
    })

    it('should process frame when state is ACTIVE', async () => {
      await runtime.start()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const trackingEngine = runtime.getTrackingEngine()
      expect(trackingEngine?.processFrame).toHaveBeenCalled()
    })

    it('should NOT process frame when state is IDLE', async () => {
      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const trackingEngine = runtime.getTrackingEngine()
      expect(trackingEngine?.processFrame).not.toHaveBeenCalled()
    })

    it('should NOT process frame when state is PAUSED', async () => {
      await runtime.start()
      await runtime.pause()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const trackingEngine = runtime.getTrackingEngine()
      expect(trackingEngine?.processFrame).not.toHaveBeenCalled()
    })

    it('should NOT process frame when state is COMPLETED', async () => {
      await runtime.start()
      await runtime.stop()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const trackingEngine = runtime.getTrackingEngine()
      expect(trackingEngine?.processFrame).not.toHaveBeenCalled()
    })

    it('should guard against concurrent processFrame calls', async () => {
      await runtime.start()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      // Make processFrame take some time
      const trackingEngine = runtime.getTrackingEngine()
      trackingEngine!.processFrame = jest.fn().mockImplementation(
        () => new Promise(resolve => setTimeout(resolve, 100))
      )

      // Call processFrame twice concurrently
      const promise1 = runtime.processFrame(frame)
      const promise2 = runtime.processFrame(frame)

      await Promise.all([promise1, promise2])

      // Should only call processFrame once due to guard
      expect(trackingEngine?.processFrame).toHaveBeenCalledTimes(1)
    })

    it('should increment processFrameCount only when frame is processed', async () => {
      await runtime.start()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      // processFrameCount is private, but we can verify through side effects
      // For now, just ensure no error is thrown
      expect(runtime.getState()).toBe('ACTIVE')
    })

    it('should call onTrackingStateUpdate callback with tracking state', async () => {
      const trackingCallback = jest.fn()
      const runtimeWithCallback = new WorkoutSessionRuntime(
        { sessionId: mockSessionId, userId: mockUserId },
        { onTrackingStateUpdate: trackingCallback }
      )

      const mockVisionEngine = createMockVisionEngine()
      const mockTrackingEngine = createMockTrackingEngine()
      const mockQueue = createMockQueue()

      runtimeWithCallback.setVisionEngine(mockVisionEngine)
      runtimeWithCallback.setTrackingEngine(mockTrackingEngine)
      runtimeWithCallback.setWorkoutQueue(mockQueue)

      await runtimeWithCallback.start()

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtimeWithCallback.processFrame(frame)

      expect(trackingCallback).toHaveBeenCalled()
    })

    it('should wait for in-flight frame before stopping', async () => {
      await runtime.start()

      const trackingEngine = runtime.getTrackingEngine()
      trackingEngine!.processFrame = jest.fn().mockImplementation(
        () => new Promise(resolve => setTimeout(resolve, 100))
      )

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      const processPromise = runtime.processFrame(frame)

      // Stop immediately after starting frame processing
      const stopPromise = runtime.stop()

      await Promise.all([processPromise, stopPromise])

      expect(runtime.getState()).toBe('COMPLETED')
    })
  })

  describe('shot detection - deduplication and normalization', () => {
    const createMockVisionEngine = () => ({
      start: jest.fn(),
      stop: jest.fn(),
      processFrame: jest.fn().mockReturnValue({
        ball: null,
        player: null,
        rim: null,
        pose: null,
        observationTimestamps: {},
      }),
      getCurrentResults: jest.fn().mockReturnValue({
        ball: null,
        player: null,
        rim: null,
        pose: null,
        poseTimestamp: null,
      }),
      setBallDetectionEnabled: jest.fn(),
      setPlayerDetectionEnabled: jest.fn(),
      setRimDetectionEnabled: jest.fn(),
      setPoseDetectionEnabled: jest.fn(),
      isReady: jest.fn(),
    })

    const createMockTrackingEngine = () => ({
      processFrame: jest.fn().mockReturnValue({
        ballPosition: null,
        ballPositionRaw: null,
        ballVelocity: null,
        hoopPosition: null,
        confidence: null,
        inFlight: false,
        shotDetected: false,
        shotResult: null,
        trajectory: [],
      }),
      resetShot: jest.fn(),
      resetAll: jest.fn(),
      getState: jest.fn(),
      getComparisonStats: jest.fn(),
      getCurrentPlayerPosition: jest.fn(),
    })

    const createMockQueue = () => ({
      enqueueCritical: jest.fn().mockResolvedValue(true),
      enqueueTelemetry: jest.fn(),
      flushCriticalOnly: jest.fn(),
      flushTelemetryOnly: jest.fn(),
      shutdown: jest.fn().mockResolvedValue(undefined),
      criticalSize: 0,
      telemetrySize: 0,
      telemetryDropped: 0,
      criticalOverflow: 0,
      getQueueMetrics: jest.fn().mockReturnValue({
        telemetry: { pending: 0, dropped: 0 },
        critical: { pending: 0, overflow: 0 },
      }),
    })

    beforeEach(() => {
      const mockVisionEngine = createMockVisionEngine()
      const mockTrackingEngine = createMockTrackingEngine()
      const mockQueue = createMockQueue()

      runtime.setVisionEngine(mockVisionEngine)
      runtime.setTrackingEngine(mockTrackingEngine)
      runtime.setWorkoutQueue(mockQueue)
    })

    it('should not count shot twice if same shotId is processed again (deduplication)', async () => {
      await runtime.start()

      const trackingEngine = runtime.getTrackingEngine()
      const shotId = 'shot-123'

      // Simulate a shot detection with the same ID twice
      trackingEngine!.processFrame = jest.fn().mockReturnValue({
        ballPosition: { x: 0.5, y: 0.5 },
        ballPositionRaw: { x: 0.5, y: 0.5 },
        ballVelocity: { vx: 0, vy: 0 },
        hoopPosition: { x: 0.5, y: 0.3 },
        confidence: 0.9,
        inFlight: false,
        shotDetected: true,
        shotResult: 'MADE',
        shotId: shotId,
        trajectory: [],
      })

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      // First shot
      await runtime.processFrame(frame)
      let metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(1)
      expect(metrics.madeShots).toBe(1)

      // Same shot ID again (should be deduplicated)
      await runtime.processFrame(frame)
      metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(1) // Still 1, not 2
      expect(metrics.madeShots).toBe(1)
    })

    it('should not increment metrics if enqueueCritical fails', async () => {
      await runtime.start()

      const queue = runtime['workoutQueue']
      queue!.enqueueCritical = jest.fn().mockResolvedValue(false)

      const trackingEngine = runtime.getTrackingEngine()
      trackingEngine!.processFrame = jest.fn().mockReturnValue({
        ballPosition: { x: 0.5, y: 0.5 },
        ballPositionRaw: { x: 0.5, y: 0.5 },
        ballVelocity: { vx: 0, vy: 0 },
        hoopPosition: { x: 0.5, y: 0.3 },
        confidence: 0.9,
        inFlight: false,
        shotDetected: true,
        shotResult: 'MADE',
        shotId: 'shot-456',
        trajectory: [],
      })

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const metrics = runtime.getMetrics()
      expect(metrics.totalShots).toBe(0) // Not incremented
      expect(metrics.madeShots).toBe(0)
    })

    it('should normalize AIRBALL to MISS for public contract', async () => {
      await runtime.start()

      const trackingEngine = runtime.getTrackingEngine()
      const shotCallback = jest.fn()

      const runtimeWithCallback = new WorkoutSessionRuntime(
        { sessionId: mockSessionId, userId: mockUserId },
        { onShotDetected: shotCallback }
      )

      const mockVisionEngine = createMockVisionEngine()
      const mockTrackingEngine = createMockTrackingEngine()
      const mockQueue = createMockQueue()

      runtimeWithCallback.setVisionEngine(mockVisionEngine)
      runtimeWithCallback.setTrackingEngine(mockTrackingEngine)
      runtimeWithCallback.setWorkoutQueue(mockQueue)

      await runtimeWithCallback.start()

      mockTrackingEngine.processFrame = jest.fn().mockReturnValue({
        ballPosition: { x: 0.5, y: 0.5 },
        ballPositionRaw: { x: 0.5, y: 0.5 },
        ballVelocity: { vx: 0, vy: 0 },
        hoopPosition: { x: 0.5, y: 0.3 },
        confidence: 0.9,
        inFlight: false,
        shotDetected: true,
        shotResult: 'AIRBALL', // Internal result
        shotId: 'shot-789',
        trajectory: [],
      })

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtimeWithCallback.processFrame(frame)

      // Callback should receive normalized result (MISS, not AIRBALL)
      expect(shotCallback).toHaveBeenCalledWith('MISS')
    })

    it('should distinguish manual shots from automatic shots in tracking data', async () => {
      await runtime.start()

      // Manual shot
      await runtime.registerManualShot('MADE')

      const queue = runtime['workoutQueue'] as any
      const manualCall = queue.enqueueCritical.mock.calls[0]
      const manualPayload = manualCall[0].payload

      expect(manualPayload.trackingData).toContain('manualEntry')

      // Reset for automatic shot
      queue.enqueueCritical.mockClear()

      const trackingEngine = runtime.getTrackingEngine()
      trackingEngine!.processFrame = jest.fn().mockReturnValue({
        ballPosition: { x: 0.5, y: 0.5 },
        ballPositionRaw: { x: 0.5, y: 0.5 },
        ballVelocity: { vx: 0, vy: 0 },
        hoopPosition: { x: 0.5, y: 0.3 },
        confidence: 0.9,
        inFlight: false,
        shotDetected: true,
        shotResult: 'MADE',
        shotId: 'shot-auto',
        trajectory: [],
      })

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      await runtime.processFrame(frame)

      const autoCall = queue.enqueueCritical.mock.calls[0]
      const autoPayload = autoCall[0].payload

      // Automatic shot should NOT have manualEntry flag
      expect(autoPayload.trackingData).not.toContain('manualEntry')
    })

    it('should handle shot without shotId gracefully', async () => {
      await runtime.start()

      const trackingEngine = runtime.getTrackingEngine()
      trackingEngine!.processFrame = jest.fn().mockReturnValue({
        ballPosition: { x: 0.5, y: 0.5 },
        ballPositionRaw: { x: 0.5, y: 0.5 },
        ballVelocity: { vx: 0, vy: 0 },
        hoopPosition: { x: 0.5, y: 0.3 },
        confidence: 0.9,
        inFlight: false,
        shotDetected: true,
        shotResult: 'MADE',
        shotId: undefined, // No ID
        trajectory: [],
      })

      const frame = {
        width: 1920,
        height: 1080,
        timestamp: Date.now(),
      }

      // Should not throw
      await expect(runtime.processFrame(frame)).resolves.not.toThrow()
    })
  })
})
