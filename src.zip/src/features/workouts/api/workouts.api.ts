// saveCourtCalibration sends flat fields (hoopCenterX/Y) aligned with BE CalibrationRequest

import AsyncStorage from '@react-native-async-storage/async-storage'
import apiClient from '@/shared/api/apiClient'
import { API_BASE_URL } from '@/config/appConfig'
import {
    WorkoutSession, CreateWorkoutSessionPayload,
    ShotEvent, AddShotEventPayload,
    CalibrationData, ShotChartResponse,
    ZoneStatistics, CareerStats,
    FrameDataPayload, PoseAnalysisPayload,
} from '../types/workouts.types'

// Sessions

export const createWorkoutSession = async (
    userId: string, payload: CreateWorkoutSessionPayload
): Promise<WorkoutSession> => {
    console.log('API call: POST /workouts/sessions', { userId, payload })
    const r = await apiClient.post<WorkoutSession>(
        `/workouts/sessions?userId=${userId}`, payload)
    console.log('API response:', r.data)
    return r.data
}

export const getWorkoutSession = async (
    sessionId: string, userId: string
): Promise<WorkoutSession> => {
    const r = await apiClient.get<WorkoutSession>(
        `/workouts/sessions/${sessionId}?userId=${userId}`)
    return r.data
}

export const getPlayerWorkoutSessions = async (
    userId: string
): Promise<WorkoutSession[]> => {
    const r = await apiClient.get<WorkoutSession[]>(
        `/workouts/sessions?userId=${userId}`)
    return r.data
}

export const deleteWorkoutSession = async (
    sessionId: string, userId: string
): Promise<void> => {
    // Use native fetch for DELETE to avoid axios header issues
    const token = await AsyncStorage.getItem('token')

    const headers: Record<string, string> = {}
    if (token && typeof token === 'string' && token.trim() !== '') {
        headers['Authorization'] = `Bearer ${token.trim()}`
    }

    const response = await fetch(
        `${API_BASE_URL}/api/workouts/sessions/${sessionId}?userId=${userId}`,
        {
            method: 'DELETE',
            headers,
        }
    )

    if (!response.ok) {
        throw new Error(`Failed to delete session: ${response.status}`)
    }
}

export const endWorkoutSession = async (
    sessionId: string, userId: string
): Promise<WorkoutSession> => {
    const r = await apiClient.post<WorkoutSession>(
        `/workouts/sessions/${sessionId}/end?userId=${userId}`)
    return r.data
}

export const pauseWorkoutSession = async (
    sessionId: string, userId: string
): Promise<WorkoutSession> => {
    const r = await apiClient.post<WorkoutSession>(
        `/workouts/sessions/${sessionId}/pause?userId=${userId}`)
    return r.data
}

export const resumeWorkoutSession = async (
    sessionId: string, userId: string
): Promise<WorkoutSession> => {
    const r = await apiClient.post<WorkoutSession>(
        `/workouts/sessions/${sessionId}/resume?userId=${userId}`)
    return r.data
}

export const getActiveWorkoutSession = async (
    userId: string
): Promise<WorkoutSession | null> => {
    try {
        const r = await apiClient.get<WorkoutSession>(
            `/workouts/sessions/active-session?userId=${userId}`)
        return r.data
    } catch (e: any) {
        if (e?.response?.status === 404) return null
        throw e
    }
}

// Shots

export const getSessionShots = async (
    sessionId: string, userId: string
): Promise<ShotEvent[]> => {
    const r = await apiClient.get<ShotEvent[]>(
        `/workouts/sessions/${sessionId}/shots?userId=${userId}`)
    return r.data
}

export const addShotEvent = async (
    sessionId: string, userId: string, payload: AddShotEventPayload
): Promise<ShotEvent> => {
    const r = await apiClient.post<ShotEvent>(
        `/workouts/sessions/${sessionId}/shots?userId=${userId}`, payload)
    return r.data
}

export const addShotEventsBatch = async (
    sessionId: string, userId: string, payloads: AddShotEventPayload[]
): Promise<ShotEvent[]> => {
    if (payloads.length === 0) return []
    
    const r = await apiClient.post<ShotEvent[]>(
        `/workouts/sessions/${sessionId}/shots/batch?userId=${userId}`,
        { shots: payloads }
    )
    return r.data
}

// Calibration
// BE uses flat fields (hoopCenterX/Y), FE uses nested (hoopCenter: {x, y})

export const saveCourtCalibration = async (
    sessionId: string,
    userId: string,
    data: CalibrationData
): Promise<void> => {
    const body: Record<string, any> = {
        // Flatten: hoopCenter.x/y → hoopCenterX/Y
        hoopCenterX: data.hoopCenter.x,
        hoopCenterY: data.hoopCenter.y,
        homographyMatrix: data.homographyMatrix.length > 0
            ? data.homographyMatrix
            : null,
    }

    // Configurable camera resolution
    if (data.cameraResolution) {
        body.cameraResolutionWidth = data.cameraResolution.width
        body.cameraResolutionHeight = data.cameraResolution.height
    }

    // Optional court corners
    if (data.courtCorners) {
        const { topLeft, topRight, bottomRight, bottomLeft } = data.courtCorners
        body.threePointLineTopX    = topLeft.x
        body.threePointLineTopY    = topLeft.y
        body.threePointLineRightX  = topRight.x
        body.threePointLineRightY  = topRight.y
        body.sidelineRightX        = bottomRight.x
        body.sidelineRightY        = bottomRight.y
        body.sidelineLeftX         = bottomLeft.x
        body.sidelineLeftY         = bottomLeft.y
    }

    await apiClient.post(
        `/workouts/sessions/${sessionId}/calibration?userId=${userId}`,
        body
    )
}

// AI Tracking - Frame Data

export const saveFrameData = async (
    sessionId: string, userId: string, payload: FrameDataPayload
): Promise<void> => {
    try {
        await apiClient.post(
            `/workouts/sessions/${sessionId}/frames?userId=${userId}`, payload)
    } catch {
        // Best-effort - don't block session
    }
}

export const saveFrameDataBatch = async (
    sessionId: string,
    userId: string,
    frames: FrameDataPayload[]
): Promise<void> => {
    if (frames.length === 0) return

    await apiClient.post(
        `/workouts/sessions/${sessionId}/frames/batch?userId=${userId}`,
        {
            frames,
        }
    )
}

// AI Tracking - Pose Analysis

export const savePoseAnalysis = async (
    sessionId: string, userId: string, payload: PoseAnalysisPayload
): Promise<void> => {
    try {
        await apiClient.post(
            `/workouts/sessions/${sessionId}/pose-analysis?userId=${userId}`, payload)
    } catch {
        // Best-effort
    }
}

// Analytics

export const getShotChart = async (
    sessionId: string, userId: string
): Promise<ShotChartResponse> => {
    const r = await apiClient.get<ShotChartResponse>(
        `/workouts/${sessionId}/analytics/shot-chart?userId=${userId}`)
    return r.data
}

export const getSessionStatistics = async (
    sessionId: string, userId: string
): Promise<any> => {
    const r = await apiClient.get(
        `/workouts/${sessionId}/analytics/stats?userId=${userId}`)
    return r.data
}

export const getZoneStatistics = async (
    sessionId: string, userId: string
): Promise<ZoneStatistics[]> => {
    const r = await apiClient.get<ZoneStatistics[]>(
        `/workouts/${sessionId}/analytics/zones?userId=${userId}`)
    return r.data
}

export const getHotZoneShots = async (
    sessionId: string, userId: string, limit = 10
): Promise<ShotEvent[]> => {
    const r = await apiClient.get<ShotEvent[]>(
        `/workouts/${sessionId}/analytics/hot-zones?userId=${userId}&limit=${limit}`)
    return r.data
}

export const getColdZoneShots = async (
    sessionId: string, userId: string, limit = 10
): Promise<ShotEvent[]> => {
    const r = await apiClient.get<ShotEvent[]>(
        `/workouts/${sessionId}/analytics/cold-zones?userId=${userId}&limit=${limit}`)
    return r.data
}

export const getCareerStatistics = async (userId: string): Promise<CareerStats> => {
    const r = await apiClient.get<CareerStats>(
        `/workouts/player/analytics/career-stats?userId=${userId}`)
    return r.data
}
