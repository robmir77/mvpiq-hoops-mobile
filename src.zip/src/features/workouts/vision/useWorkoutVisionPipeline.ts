// useWorkoutVisionPipeline
// Phase 2: Cleaner interface for vision pipeline
// Wraps existing useCameraPipeline with a cleaner API
// This is a stepping stone to full extraction

import { useMemo } from 'react'
import { useCameraPipeline } from '@/vision'
import type { BallDetection, PoseResult, ShotEvent } from '@/vision'
import type { AndroidDelegateOption, IosDelegateOption } from '@/vision/delegates'
import type { VisionPipelineConfig } from './WorkoutVisionPipeline.types'

export interface UseWorkoutVisionPipelineResult {
  // Camera
  device: any
  hasPermission: boolean
  isActive: boolean
  requestPermission: () => Promise<boolean>
  setIsActive: (v: boolean) => void
  frameOutput: any
  
  // Vision state
  isModelReady: boolean
  
  // Actions
  start(): void
  stop(): void
  resetShotTracking(): void
  
  // FPS metrics
  fpsMetrics: {
    yoloFps: number
    moveNetFps: number
    actualCameraFps: number
  }
  
  // Shared values for overlay
  sharedValues: any
}

export const useWorkoutVisionPipeline = (
  config: VisionPipelineConfig,
  onBallDetection: (detection: BallDetection) => void,
  onPoseResult: (result: PoseResult) => void,
  onShotEvent: (event: ShotEvent) => void,
  onRimDetection?: (rim: { x: number; y: number; width: number; height: number; confidence: number }) => void,
): UseWorkoutVisionPipelineResult => {
  const {
    device,
    hasPermission,
    isActive,
    requestPermission,
    setIsActive,
    frameOutput,
    isModelReady,
    resetShotTracking,
    yoloFps,
    moveNetFps,
    actualCameraFps,
    actualYoloFps,
    actualMoveNetFps,
    sharedValues,
  } = useCameraPipeline(
    onBallDetection,
    onPoseResult,
    onShotEvent,
    onRimDetection,
    config.rimFromCalibration,
    config.kalmanFilteredBall,
    config.enabled,
    config.poseEnabled,
    config.ballEnabled,
    config.rimEnabled,
    config.yoloDelegate as AndroidDelegateOption | IosDelegateOption | null,
    config.poseDelegate as AndroidDelegateOption | IosDelegateOption | null,
    config.yoloModelId,
    config.selectedResolution,
    config.selectedFps,
    config.selectedPoseResolution,
    config.moveNetModelId,
  )

  const start = () => {
    setIsActive(true)
  }

  const stop = () => {
    setIsActive(false)
  }

  return {
    // Camera
    device,
    hasPermission,
    isActive,
    requestPermission,
    setIsActive,
    frameOutput,

    // Vision state
    isModelReady,

    // Actions
    start,
    stop,
    resetShotTracking,

    // FPS metrics (extract values from SharedValues)
    fpsMetrics: {
      yoloFps: actualYoloFps?.value ?? 0,
      moveNetFps: actualMoveNetFps?.value ?? 0,
      actualCameraFps: actualCameraFps?.value ?? 0,
    },

    // Shared values (for overlay)
    sharedValues,
  }
}
