# MVPIQ Hoops - Architecture Decisions

## Model Configurations

### YOLO Models

| Model ID | Input Size | Precision | Epochs | Expected FPS | Actual FPS | Note |
|----------|------------|-----------|--------|--------------|------------|------|
| best_320_float16 | 320x320 | FP16 | 50 | 10-37 | 2-7 | Measured at 640x360 resolution |
| best_384_float16 | 384x384 | FP16 | 100 | 20-21 | 3-6 | Updated to 100 epochs, actual FPS lower due to device bottleneck |
| best_448_float16 | 448x448 | FP16 | 5 | 12-21 | TBD | Early training |
| best_512_float16 | 512x512 | FP16 | 40 | 8-10 | TBD | Balanced performance |
| best_640_float16 | 640x640 | FP16 | 30 | 5-7 | TBD | High resolution |

## Decision 0: Rimozione Throttling Temporale (Natural FPS)

---

## Decision 0.1: Sincronizzazione Reanimated Shared Values

**Contesto:** I shared values di Reanimated (es. `actualCameraFps.value`) venivano letti direttamente durante il render dei componenti React, causando warning di Reanimated: "Reading from `value` during component render."

**Decisione:**
- Sincronizzare i shared values a variabili di stato regolari tramite useEffect
- `WorkoutSessionScreen.tsx`: aggiunto `cameraFps` state aggiornato ogni 1000ms da `actualCameraFps.value`
- `TelemetryOverlay.tsx`: riceve `cameraFps` come prop regolare invece di shared value
- Stesso pattern applicato per `yoloFps` e `moveNetFps`

**Rationale:**
- Reanimated richiede che i shared values non siano letti durante il render
- La sincronizzazione tramite useEffect garantisce che il valore sia disponibile come state regolare
- Evita warning e potenziali problemi di performance

**Conseguenze:**
- Warning Reanimated eliminati
- FPS metrics aggiornati ogni secondo (sufficiente per UI)
- Componenti UI ricevono props regolari invece di shared values
- Architettura più pulita con separazione tra vision layer (shared values) e UI layer (state)

---

**Contesto:** Il sistema throttling deterministico (YOLO 10 FPS, MoveNet 3 FPS) limitava artificialmente la detection rate. Rimuovendo i limiti temporali, i modelli possono girare al massimo FPS possibile dato il tempo di inferenza sincrono.

**Decisione:**
- Rimozione completa del throttling temporale da YOLO e MoveNet
- Rimozione di VISION_CONFIG.YOLO.TARGET_FPS e VISION_CONFIG.MOVENET.TARGET_FPS
- YOLO esegue ogni frame se `!isProcessing` (work-limited, throughput varia con device load)
- MoveNet esegue ogni frame se `!isProcessing` e bbox player valido (work-limited, throughput varia con device load)
- Camera FPS: 30 (configurabile via CAMERA_CONFIG.DEFAULT_FPS)
- Tracking: realtime (ogni frame)
- Bridge calls: 15 FPS (throttled a 66ms)

**Rationale:**
- L'architettura sincrona attuale (runSync() nel worklet) ha un limite naturale basato sul tempo di inferenza
- Ogni inferenza YOLO costa ~35-45ms (resize + run + parse)
- Ogni inferenza MoveNet costa ~150-160ms (crop + resize + quantization + run + parse)
- Rimuovere limiti artificiali massimizza la detection rate
- YOLO/MoveNet sono work-limited: eseguono quando disponibili, throughput varia con device load
- Sistema più semplice senza logica di throttling temporale

**Conseguenze:**
- Camera può girare a 30 FPS indipendentemente da YOLO/MoveNet
- YOLO è work-limited: esegue quando disponibile, throughput varia con device load (nessuna garanzia numerica, dipende da latenza inferenza + scheduling)
- MoveNet è work-limited: esegue quando disponibile e bbox player valido, throughput varia con device load (nessuna garanzia numerica, dipende da latenza inferenza + scheduling)
- Tracking usa l'ultimo risultato YOLO + Kalman prediction nei frame intermedi
- Telemetry YOLO throttled a 15 FPS (66ms) per ridurre overhead bridge
- Nessun limite temporale artificiale che riduce detection rate
- Configurazione semplice in VISION_CONFIG (solo ENABLED flags)

---

## Decision 0.5: Rimozione Scheduler Duplicati (Single Responsibility)

**Contesto:** useShotTracker.ts conteneva scheduler duplicati per YOLO e MoveNet, creando confusione e accoppiamento inappropriato. Lo scheduling esterno in useShotTracker usava selectedFps (camera FPS) mentre lo scheduling interno nei worker usava VISION_CONFIG (target FPS deterministici).

**Decisione:**
- Rimozione completa dello scheduling YOLO da useShotTracker.ts
- Rimozione completo dello scheduling MoveNet da useShotTracker.ts
- I worker (useYoloWorker, useMoveNetWorker) sono gli unici responsabili del proprio scheduling
- useShotTracker chiama processFrame() ogni frame per entrambi i worker
- Ogni worker decide internamente se eseguire in base a `isProcessing` flag
- Rimozione residui adaptive performance (TARGET_DETECTION_RATE, ADAPTATION_WINDOW_MS, lastAdjustmentTs, updateAdaptiveThreshold)
- Rimozione currentModelIndex e commenti adaptiveModelIndex

**Rationale:**
- Single Responsibility Principle: ogni worker gestisce il proprio scheduling
- Elimina accoppiamento tra camera FPS e worker FPS
- Rimuove ridondanza: ShotTracker scheduler → Worker scheduler
- Semplifica diagnosi: un solo punto di decisione per ogni worker
- Metriche FPS diventano semanticamente corrette (throughput reale vs teorico)
- Log più comprensibili: non c'è più confusione tra scheduler esterno e interno

**Conseguenze:**
- Architettura pulita: Camera → ShotTracker → Worker (con scheduling interno)
- YOLO: scheduling interno basato su `isProcessing` flag (no throttling temporale)
- MoveNet: scheduling interno basato su `isProcessing` flag e bbox player valido (no throttling temporale)
- useShotTracker: orchestrazione semplice, chiama workers ogni frame
- Nessun accoppiamento tra selectedFps e worker scheduling
- Code più facile da mantenere e debuggare

**Risultati (post-implementazione):**
- Camera FPS migliorata da ~4 FPS a 10-14 FPS (senza throttling)
- YOLO FPS naturale varia con device load (nessuna garanzia numerica, work-limited)
- MoveNet FPS naturale varia con device load (nessuna garanzia numerica, work-limited, limitato da disponibilità bbox player)
- Log molto più leggibili e semanticamente corretti
- Problema spostato da "chi decide quando eseguire" a "quanto costa elaborare un frame"
- ✅ Sincronizzazione shared values → state implementata per evitare warning Reanimated

**Roadmap (non implementata):**
1. ✅ Rinominare metriche fps → throughputFps/theoreticalFps per chiarezza semantica
2. ✅ Rimozione throttling temporale per massimizzare detection rate
3. ✅ Sincronizzazione Reanimated shared values per evitare warning
4. ✅ Rimozione garanzie FPS numeriche da ARCHITECTURE_DECISIONS.md (YOLO è work-limited)
5. ✅ Documentare interpretazione metriche latenza YOLO (Decision 0.9)
6. ✅ Marcare Decision 29 come REVERTED/SUPERSEDED (legacy vision removal)
7. ✅ Esperimento YOLO 320 vs 384 (Decision 0.91) - concluso: mantenere 384 come default
8. ✅ Analisi Expo Debug vs Release (Decision 0.91 aggiornata) - ipotesi: Debug overhead maschera performance reali
9. **🔴 CRITICO: Verificare saturazione/lifecycle ShotTracker** - PRIORE ASSOLUTA
   - Numero ShotTracker mount simultanei (verificare log MOUNT/UNMOUNT)
   - Numero modelli YOLO caricati (verificare log MODEL STATE)
   - Modelli ancora caricati dopo unmount
   - Callback scheduleOnRN pendenti
   - MoveNet model lifecycle
   - Eventuali Frame/GPUBuffer non rilasciati
10. **🔴 CRITICO: Eliminare doppio useTensorflowModel in useShotTracker**
    - Attualmente: useYoloWorker + useYoloWorkerAsync caricano entrambi useTensorflowModel
    - Solo useYoloWorkerAsync viene usato per inferenza (ENABLE_ASYNC_YOLO_POC = true)
    - Obiettivo: caricare solo un modello TFLite
11. **Testare 5 workout consecutivi per confermare saturazione**
    - Confrontare: Workout #1, #2, #3, #4, #5
    - Metriche: YOLO FPS, YOLO inference P50, YOLO schedule P50, MoveNet FPS, Camera FPS
12. Test controllato Expo Debug vs Release (60 secondi ciascuno)
13. Misurare separatamente tempo totale del frame processor
14. Analizzare e ridurre costo MoveNet CPU crop (~30 ms)
15. Investigare parallelizzazione YOLO/MoveNet

---

## Decision 0.9: Interpretazione Metriche Latenza YOLO

**Contesto:** YOLO è work-limited con throughput variabile (5.9-36 FPS osservati). I picchi di latenza (116-195 ms) possono essere causati da schedule wait o vera inferenza. È necessario distinguere le due componenti per ottimizzare correttamente.

**Metriche Disponibili (PERF 1s):**
```
YOLO DETAIL workletPrep=Xms schedule=Yms (P50=A P95=B P99=C) jsPreprocess=Dms inference=Ems postprocess=Fms resize=Gms run=Hms parse=Ims
```

**Componenti Latenza:**
- `workletPrep` (A→B): tempo nel worklet prima di scheduleOnRN (resize + buffer extraction)
- `schedule` (B→C): attesa tra scheduleOnRN e callback start (RN scheduling contention)
- `jsPreprocess` (C→D): preprocessing sul JS thread (0 per YOLO, significativo per MoveNet)
- `inference` (D→E): vera inferenza TFLite (runSync)
- `postprocess` (E→F): parsing output + aggiornamento shared values

**Interpretazione:**
- Se `schedule` (P50/P95/P99) è alto (es. >50ms): il collo di bottiglia è RN scheduling contention
  - Soluzione: ottimizzare scheduleOnRN, ridurre crossing bridge, parallelizzare
- Se `inference` è alto (es. >100ms): il collo di bottiglia è vera inferenza YOLO
  - Soluzione: ottimizzare modello (input size, quantization, pruning), cambiare delegate
- Se `workletPrep` è alto: il collo di bottiglia è resize nel worklet
  - Soluzione: ottimizzare resizer, ridurre input size

**Nota Importante:**
L'architettura attuale è `worklet → scheduleOnRN() → RN/JS callback → runSync()`. Questo significa che:
- `runSync()` occupa il thread RN/JS per ~72-110ms durante l'inferenza
- Questo può contribuire indirettamente allo schedule wait dei callback successivi
- YOLO e MoveNet competono per lo stesso thread RN/JS con la stessa strategia async/scheduleOnRN
- Lo schedule wait non è quindi un problema completamente indipendente dall'inferenza

**Esempio Diagnosi:**
```
schedule=31ms, inference=102ms → Totale=133ms, inference=77% del costo
→ In condizioni normali, l'inferenza è il costo dominante
```

```
schedule=159ms, inference=100ms → Totale=259ms, schedule=61% del costo
→ Nei picchi, lo schedule wait diventa dominante
```

**Dati Reali (da log):**
- Schedule wait: P50≈44ms, P95≈96ms, P99≈122ms, picchi fino a 159ms
- Inference: 72-110ms (media ~90ms)
- In condizioni normali: inference è ~60-70% del costo totale
- Nei picchi: schedule wait può diventare il componente maggiore

**Rationale:**
- Distinguere schedule wait da inference è cruciale per decidere dove ottimizzare
- P50/P95/P99 mostrano la distribuzione reale, non solo la media
- Le metriche sono già raccolte in telemetry.ts e mostrate in PERF 1s
- La correlazione tra runSync() e schedule wait deve essere considerata

**Conseguenze:**
- PERF 1s fornisce già tutte le metriche necessarie per la diagnosi
- Analisi basata su dati reali, non su assunzioni
- Decisioni di ottimizzazione guidate da misurazioni accurate
- Non introdurre throttling temporale: !isProcessing è coerente con latest-frame-wins

---

## Decision 0.91: Esperimento YOLO 320 vs 384

**Contesto:** Per valutare se ridurre l'input size YOLO da 384 a 320 migliora le performance senza compromettere la detection quality.

**Configurazione Test:**
- YOLO 320: input=320x320, camera=1280x720, delegate=android-gpu
- YOLO 384: input=384x384, camera=1280x720, delegate=android-gpu (baseline)

**Metriche YOLO 320:**
- Inference: 58-122ms (media ~68-95ms)
- Schedule: 24-195ms (P50=47-48ms, P95=96-100ms)
- Throughput: 4.8-15.0 FPS
- Ball detection: 95-97%
- Player detection: 34-48%
- FP rate: 40-53%

**Metriche YOLO 384 (baseline):**
- Inference: 72-110ms (media ~90ms)
- Schedule: 31-159ms (P50=44ms, P95=96ms)
- Throughput: 5.9-12.7 FPS
- Ball detection: 94-97%
- Player detection: 40-58%
- FP rate: 42-53%

**Risultati:**
- Inference: leggermente migliorata con 320 (~68-95ms vs ~90ms con 384, guadagno ~15-25ms)
- Schedule: simile (P50=47-48ms vs 44ms con 384)
- Ball detection: simile (95-97% vs 94-97% con 384)
- Player detection: **peggiorata** con 320 (34-48% vs 40-58% con 384)
- FP rate: simile (40-53% vs 42-53% con 384)

**Decisione:**
YOLO 320 offre un guadagno marginale di latenza (~15-25ms) ma peggiora significativamente la player detection. Il guadagno di throughput non giustifica la perdita di detection quality. Mantenere YOLO 384 come default.

**Rationale:**
- La detection quality è più importante del throughput marginale
- Player detection peggiore (34-48% vs 40-58%) è un segnale negativo
- Il guadagno di latenza ~15-25ms non è sufficiente a giustificare la perdita di accuracy

**Nuova evidenza importante (Release Build):**
Il build release sul dispositivo reale mostra:
- YOLO: 14-22 FPS (picco ~18 FPS)
- Camera: ~28 FPS
- MoveNet: ~7 FPS
- Ball detection: 73%
- Player detection: 31%

Questo è perfettamente compatibile con il range atteso del modello 384 dal registry (20-21 FPS). Questo suggerisce che i benchmark precedenti in Expo Debug non erano rappresentativi delle performance reali del prodotto.

**Ipotesi: Expo Debug vs Release**
La differenza tra Expo Debug e Release può essere dovuta a:
- Overhead JS in modalità development
- Logging più pesante
- DevTools/debug infrastructure
- Fast Refresh overhead
- runSync() eseguito sul thread JS/RN tramite scheduleOnRN

L'architettura async attuale (worklet → scheduleOnRN → runSync()) è particolarmente sensibile al carico del thread JS/RN. Se il runtime di sviluppo rende il thread JS più pesante, c'è un effetto moltiplicativo sul schedule wait e quindi sul throughput.

**Prossima azione: Test controllato**
Non ottimizzare ulteriormente il modello (input size, pruning, quantization) finché non viene confermato tramite test controllato:
- Test A: Expo Debug (60 secondi)
- Test B: Release build (60 secondi)

Metriche da raccogliere:
- Camera FPS
- YOLO executed FPS
- YOLO inference P50/P95/P99
- YOLO schedule P50/P95/P99
- MoveNet FPS
- Ball detection %
- Player detection %

Se il release build conferma ~15-20 FPS con inference significativamente più bassa, abbiamo dimostrato che i benchmark Expo Debug non erano rappresentativi.

---

## Decision 0.92: Saturazione Progressiva - Doppio Caricamento Modello YOLO

**Contesto:** L'utente ha osservato che dopo più workout consecutivi, le prestazioni YOLO peggiorano progressivamente fino a raggiungere le stesse prestazioni di Expo Debug (~18 FPS). Questo pattern indica una possibile saturazione/leak di risorse.

**Problema Identificato:**
In `useShotTracker.ts`, vengono chiamati entrambi:
```typescript
const yoloWorkerSync = useYoloWorker(
  ballEnabled && !TEST_CONFIG.ENABLE_ASYNC_YOLO_POC,
  ...
)

const yoloWorkerAsync = useYoloWorkerAsync(
  ballEnabled && TEST_CONFIG.ENABLE_ASYNC_YOLO_POC,
  ...
)
```

Con `ENABLE_ASYNC_YOLO_POC = true`, il worker sincrono è disabilitato logicamente, ma entrambi gli hook vengono comunque eseguiti. Dentro `useYoloWorker` e `useYoloWorkerAsync`, entrambi chiamano:
```typescript
const yoloModel = useTensorflowModel(yoloModelSource, yoloDelegates)
```

**Architettura Attuale:**
```
useShotTracker
       │
       ├── useYoloWorker() → useTensorflowModel() → modello A
       │
       └── useYoloWorkerAsync() → useTensorflowModel() → modello B
```

Solo il modello B viene usato per l'inferenza, ma entrambi sono caricati in memoria. Questo spiega la saturazione progressiva dopo più workout.

**Problema Secondario:**
In `useYoloWorkerAsync`, il callback schedulato con `scheduleOnRN(runYoloInference, ...)` può essere in coda quando la sessione viene smontata. Dentro `runYoloInference()` non c'è un controllo iniziale `if (!isMountedRef.current) return` prima di eseguire `yoloModelInstance!.runSync(...)`.

**Decisione:**
Eliminare il doppio caricamento del modello TFLite. Obiettivo: caricare solo un modello YOLO.

**Soluzione Architetturale:**
1. ✅ Rimuovere `useYoloWorker` da `useShotTracker` (non più necessario con ENABLE_ASYNC_YOLO_POC = true)
2. ✅ Mantenere solo `useYoloWorkerAsync`
3. ✅ Aggiungere controllo `isMountedRef` in `processYoloAsync` (già presente alla riga 227)
4. Verificare che il modello venga rilasciato correttamente all'unmount

**Roadmap:**
1. ✅ Verificare saturazione/lifecycle ShotTracker (log MOUNT/UNMOUNT, MODEL STATE)
2. ✅ Eliminare doppio useTensorflowModel
3. **Testare 4 workout consecutivi (60s ciascuno) per confermare risoluzione**
   - Metriche: YOLO FPS, YOLO inference P50/P95/P99, YOLO schedule P50/P95/P99, Camera FPS, MoveNet FPS
   - Confrontare Workout 1 vs Workout 4 per verificare degradazione

---

## Decision 0.7: Correzione Metriche MoveNet Throughput

**Contesto:** La metrica `theoreticalFps` in MoveNet era calcolata come `1000 / inferenceTime`, rappresentando la capacità di latenza teorica invece del throughput reale. Inoltre, il PERF 1s mostrava sempre `MOVE fps=0.0 exec=0` perché i contatori di performance tracking non venivano aggiornati dal MoveNet worker.

**Decisione:**
- Rimozione completa di `theoreticalFps` da `useMoveNetWorker.ts` (metrica latenza-based errata)
- Implementazione throughput tracking corretto in `telemetry.ts`:
  - `moveNetStartTime` per calcolare throughput reale (executed / elapsedSeconds)
  - `moveNetSkipped` per tracciare frame scartati per bbox non valido
  - `moveNetDroppedBusy` per tracciare frame scartati per busy (latest-frame-wins)
  - `throughputFps` calcolato come `executed / elapsedSeconds` (non 1000/latency)
- Aggiornamento `TelemetryOverlay.tsx`:
  - Mostra `Req/Exec/Drop` per completezza
  - Mostra `Throughput` FPS (reale) invece di FPS generico
  - Mostra `Avg Latency` per chiarezza separata
- Correzione errore worklet: uso di SharedValues invece di accesso diretto a telemetryLogger
  - `telemetryRequested` e `telemetryExecuted` SharedValues nel worklet
  - Polling interval trasferisce i count al telemetry logger sul JS thread
- Connessione MoveNet a PERF 1s diagnostic window:
  - Aggiunti parametri performance tracking SharedValues a `useMoveNetWorker`
  - `perfMoveNetRequested`, `perfMoveNetExecuted`, `perfMoveNetSkipped`
  - `perfMoveNetInferenceTotal/Min/Max`
  - `perfMoveNetCropTotal`, `perfMoveNetQuantizationTotal`, `perfMoveNetResizeTotal`, `perfMoveNetRunTotal`, `perfMoveNetParseTotal`
  - Passati da `useShotTracker` e aggiornati nel worklet quando le inferenze completano

**Rationale:**
- `theoreticalFps` (1000/latency) non rappresenta throughput reale con latest-frame-wins
- Throughput reale deve essere `executed / elapsedTime` per riflettere frame processati al secondo
- PERF 1s deve mostrare metriche accurate per debugging performance
- Worklet non può accedere a oggetti JS esterni (telemetryLogger) - deve usare SharedValues
- Separazione chiara tra latenza (tempo per inferenza) e throughput (inferenze per secondo)

**Conseguenze:**
- Metriche MoveNet ora semanticamente corrette:
  - `throughputFps`: inferences reali per secondo
  - `avgLatencyMs`: tempo medio inferenza
  - `requested/executed/droppedBusy`: contatori accurati
- PERF 1s mostra metriche MoveNet accurate invece di fps=0.0
- TelemetryOverlay mostra metriche più informative e corrette
- Nessun errore worklet per accesso a telemetryLogger
- Architettura worklet-safe rispettata (solo SharedValues tra worklet e JS)

**Risultati (post-implementazione):**
- PERF 1s ora mostra: `MOVE fps=X exec=Y attempt=Z skip=W avg=XXms max=YYms`
- TelemetryOverlay mostra: `Req/Exec/Drop`, `Throughput FPS`, `Avg Latency`
- Throughput reale MoveNet riflette capacità del sistema con latest-frame-wins
- Latenza separata da throughput per diagnosi più chiara

---

## Decision 0.8: Default Camera FPS 30

**Contesto:** Il default FPS della camera era impostato a 15 per testing async YOLO, ma questo limitava la performance generale dell'applicazione.

**Decisione:**
- Cambiato `CAMERA_CONFIG.DEFAULT_FPS` da 15 a 30
- Camera ora gira a 30 FPS di default
- YOLO e MoveNet continuano a girare a FPS naturale basato su tempo inferenza

**Rationale:**
- 30 FPS è lo standard per applicazioni video
- Migliore esperienza utente con frame rate più alto
- YOLO/MoveNet non dipendono dal FPS della camera (architettura decoupled)

**Conseguenze:**
- Camera: 30 FPS di default
- YOLO: FPS naturale varia con device load (work-limited, nessuna garanzia numerica)
- MoveNet: FPS naturale varia con device load (work-limited, nessuna garanzia numerica)
- Tracking: realtime (ogni frame)

---

## Decision 0.2: Unificazione Stili TelemetryOverlay

**Contesto:** TelemetryOverlay aveva stili inconsistente per diverse voci, con FPS section separata con styling diverso dalle altre sezioni.

**Decisione:**
- Rimozione sezione `fpsSection` separata con stile speciale
- Tutte le voci usano formato uniforme: `section` → `row` → `label`/`value`
- Camera, YOLO e MoveNet FPS ora su righe separate nello stesso stile delle altre metriche
- Rimozione stili `fpsSection` e `fpsLabel` non più necessari
- Ordine FPS: Camera → YOLO → MoveNet (YOLO sopra MoveNet come richiesto)

**Rationale:**
- Unificazione stili migliora consistenza visiva
- Codice più semplice con meno stili special case
- Più facile manutenzione futura

**Conseguenze:**
- Overlay più uniforme e leggibile
- Codice più pulito senza duplicazione stili
- Tutte le metriche hanno lo stesso aspetto

---

## Decision 0.3: Session Usage Time Tracking con Ref Globale

**Contesto:** Il tracking del tempo di utilizzo della sessione veniva resettato quando il componente veniva unmounted/mountato frequentemente, causando valori sempre a 0.

**Decisione:**
- Uso di `sessionStartTimeGlobal` ref per persistere timestamp di inizio tra unmount/mount
- Calcolo tempo trascorso ogni secondo basato su timestamp globale
- Display formato minuti:secondi (es. 0:17 per 17 secondi)
- Aggiornamento ogni secondo invece di ogni minuto per feedback immediato
- Timer attivo quando `isActive && isModelReady`

**Rationale:**
- I frequenti unmount/mount del componente resettavano il timer locale
- Ref globale persiste anche quando il componente viene ricreato
- Formato minuti:secondi fornisce feedback più immediato

**Conseguenze:**
- Tempo di utilizzo ora persiste tra unmount/mount
- Valori aggiornati ogni secondo per feedback immediato
- Display più informativo con secondi
- Log di debug per verificare funzionamento timer

---

## Decision 0.6: Separazione Metriche Throughput vs Latency

**Contesto:** Le metriche FPS precedenti erano semanticamente ambigue. `fps=20.4` derivava da 1000/inferenceTime, indicando la capacità di latenza teorica, non il throughput reale di inferenze al secondo. Questo causava confusione nei log: YOLO mostrava 20 FPS ma eseguiva solo ~5 inferenze/s.

**Decisione:**
- Separare chiaramente throughput da latenza nelle metriche
- `throughputFps`: inferences reali per secondo (executed / elapsedSeconds)
- `theoreticalFps`: capacità di latenza (1000 / avgInferenceTime)
- Rinominare contatori: requested/executed/skipped invece di scheduled/executed
- Aggiungere contatori MoveNet per completezza
- Nuovo formato log:
  ```
  [PERF 1s]
  CAM  fps=10.8 recv=11 proc=10 drop=1 avg=78.2ms max=142.1ms
  YOLO fps=4.9 exec=5 attempt=11 skip=6 avg=46.7ms max=58.3ms
  MOVE fps=2.9 exec=3 attempt=11 skip=8 avg=101.4ms max=114.8ms
  ```

**Rationale:**
- Elimina ambiguità tra throughput reale e capacità teorica
- Permette di distinguere limite della camera/pipeline da throttle del detector
- Log più leggibili e semanticamente corretti
- Facilita diagnosi: se camera=10, yolo=4.9, moveNet=2.9, è chiaro che il device è il bottleneck

**Conseguenze:**
- Metriche ora rispondono a tre domande distinte:
  1. Quanti frame stiamo realmente processando? (CAM fps)
  2. Quante inference YOLO/MoveNet stiamo realmente eseguendo? (YOLO/MOVE fps)
  3. Quanto costa ogni inference? (avgMs)
- Eliminato il falso fps=20 di YOLO che sembrava indicare 20 inference/s
- Log molto più comprensibili per debugging

---

## Decision 1: Separazione Pipeline Realtime vs Async

**Contesto:** La pipeline di vision deve elaborare frame a 20+ FPS, ma il backend HTTP e la persistenza non possono bloccare il realtime.

**Decisione:**
- Il frame processor non aspetta mai il backend, React state, persistenza o telemetria JS
- Tutto ciò che può essere asincrono viene separato dal percorso realtime
- YOLO/MoveNet rimangono sincroni nel worklet (runSync) come documentato da react-native-fast-tflite
- La queue async gestisce il backend e la persistenza in background

**Rationale:**
- react-native-fast-tflite documentazione per VisionCamera mostra `runSync()` nel worklet
- Il problema vero è YOLO + MoveNet sequenziali sullo stesso thread, non la sincronicità
- Non inventare pseudo-asincronità che sposta il carico sul JS thread

**Conseguenze:**
- Vision pipeline: 30 FPS realtime (camera)
- YOLO: FPS naturale varia con device load (work-limited, nessuna garanzia numerica)
- MoveNet: FPS naturale varia con device load (work-limited, nessuna garanzia numerica, limitato da disponibilità bbox player)
- Tracking: realtime (ogni frame con Kalman prediction)
- Backend telemetry: 2 Hz (sampling)
- Critical events: queue con retry
- UI: SharedValues per rendering a 60 FPS
- Bridge calls: 15 FPS (throttled)

---

## Decision 2: Queue Session-Scoped vs Singleton Globale

**Contesto:** La queue async era implementata come singleton globale, causando race condition tra sessioni.

**Decisione:**
- WorkoutAsyncQueue è session-scoped, non singleton
- Ogni sessione crea la sua istanza con `createWorkoutQueue({ sessionId, userId })`
- La queue viene distrutta alla fine della sessione con `shutdown()`

**Rationale:**
- Evita race condition tra sessioni concorrenti
- Garantisce che eventi critici non vengano mescolati tra sessioni
- Semplifica il lifecycle management

**Conseguenze:**
- Ogni sessione ha la sua queue isolata
- PersistentOutbox per eventi critici per sessione
- Pulizia automatica alla fine della sessione

---

## Decision 3: Durable Outbox per Eventi Critici

**Contesto:** Gli eventi critici (SHOT, SESSION_START, SESSION_END, CALIBRATION) non possono essere persi in caso di crash o riavvio.

**Decisione:**
- PersistentOutbox con AsyncStorage per eventi critici
- Eventi critici vengono salvati in AsyncStorage prima dell'invio
- Retry con backoff esponenziale in caso di fallimento
- Caricamento automatico di item pendenti da sessioni precedenti

**Rationale:**
- Garantisce che eventi critici non vengano persi
- Permette recovery dopo crash o riavvio
- La telemetria può essere persa (best-effort), ma gli eventi critici no

**Conseguenze:**
- SHOT, SESSION_START, SESSION_END, CALIBRATION sono persistenti
- Telemetry frame data è best-effort (bounded queue con drop oldest)
- Retry automatico con backoff esponenziale

**⚠️ NON IMPLEMENTATO:**
- `CALIBRATION` in `CalibrationScreen.tsx` chiama direttamente `saveCourtCalibration()` senza passare dalla critical queue
- `SESSION_END` in `WorkoutSessionScreen.tsx` chiama direttamente `endWorkoutSession()` senza passare dalla critical queue
- Solo `SHOT` usa realmente la PersistentOutbox
- Questo significa che CALIBRATION e SESSION_END possono essere persi se il backend è offline o se c'è un crash

---

## Decision 4: Sampling 2 Hz per Telemetry Backend

**Contesto:** Inviare ogni frame al backend (20 FPS) causa carico HTTP eccessivo.

**Decisione:**
- TelemetrySampler per limitare invio a 2 Hz (ogni 500ms)
- Solo 1 frame su 10 viene inviato al backend
- Batch di 20 frame per richiesta HTTP

**Rationale:**
- Riduce carico HTTP da 20 richieste/sec a 1 richiesta batch/sec
- Il backend non ha bisogno di ricevere ogni frame
- Sampling sufficiente per analisi post-sessione

**Conseguenze:**
- Camera: 30 FPS
- YOLO: FPS naturale varia con device load (work-limited, nessuna garanzia numerica)
- Tracking: realtime (ogni frame con Kalman prediction)
- Backend telemetry: 2 FPS
- Shot events: 100%

---

## Decision 5: Throttling Bridge scheduleOnRN

**Contesto:** scheduleOnRN viene chiamato troppo frequentemente (ogni 16ms), causando crossing JS bridge eccessivi.

**Decisione:**
- Throttling aumentato da 16ms a 66ms (15 FPS)
- SharedValues/Skia gestiscono rendering a 60 FPS
- Solo dati critici attraversano il bridge a 15 FPS

**Rationale:**
- Riduce crossing JS bridge da ~62/sec a ~15/sec
- Il rendering UI rimane fluido grazie a SharedValues
- Riduce overhead di serializzazione

**Conseguenze:**
- Bridge calls: 15 FPS (throttled a 66ms)
- YOLO telemetry: 15 FPS (throttled a 66ms)
- UI rendering: 60 FPS (via SharedValues)
- Vision pipeline: 30+ FPS (camera)

---

## Decision 6: Flush Semantics Granulari

**Contesto:** flushCritical() e flushTelemetry() chiamavano entrambi lo stesso metodo flush(), causando confusione.

**Decisione:**
- flushCriticalOnly() - processa solo critical queue
- flushTelemetryOnly() - processa solo telemetry queue
- flushAll() - processa entrambe le queue
- shutdown() - flushAll() + pulizia outbox

**Rationale:**
- Semantica chiara per ogni operazione
- Permette flush selettivo a seconda del contesto
- shutdown() garantisce pulizia completa

**Conseguenze:**
- Fine sessione: shutdown() per flush completo
- Mid-session: flushCriticalOnly() per eventi urgenti
- Telemetry: flushTelemetryOnly() per dati non critici

---

## Decision 7: Propagazione Errori da saveFrameDataBatch

**Contesto:** saveFrameDataBatch() ingoiava gli errori, rendendo impossibile il retry a livello queue.

**Decisione:**
- saveFrameDataBatch() propaga errori al chiamante
- La queue decide cosa fare (telemetry = drop, critical = retry)
- Error handling centralizzato nella queue

**Rationale:**
- La queue deve controllare la strategia di retry
- Telemetry può essere persa (best-effort)
- Critical events devono essere ritentati

**Conseguenze:**
- Errori HTTP vengono gestiti dalla queue
- Telemetry: drop su errore
- Critical: retry con backoff

---

## Decision 8: Flag Compile/Config per Log Hot Path

**Contesto:** Log __DEV__ nel hot path causano overhead di serializzazione e allocation.

**Decisione:**
- debugConfig.ts con flag centralizzati
- HOT_PATH_LOGS disabilitato di default anche in DEV
- ENABLE_PLAYER_CROP_LOGS, ENABLE_ADAPTIVE_PERFORMANCE_LOGS, ENABLE_MOVENET_LOGS
- Flag possono essere abilitati singolarmente per debugging

**Rationale:**
- Elimina overhead di log in produzione
- Permette debugging selettivo
- Centralizzazione della configurazione

**Conseguenze:**
- Nessun log hot path in produzione
- Debugging selettivo per componente
- Facile toggle per performance testing

---

## Decision 9: Ring Buffer per detectionHistory

**Contesto:** detectionHistory usava array con push/filter, creando continuamente nuovi array.

**Decisione:**
- Ring buffer con dimensione fissa (60 elementi)
- Index ciclico per evitare allocation
- Contatore per tracciare elementi validi

**Rationale:**
- Evita allocation continue
- Performance prevedibile
- Memoria costante

**Conseguenze:**
- detectionHistory: ring buffer 60 elementi
- Nessuna allocation durante runtime
- Memory footprint costante

---

## Decision 10: Set → Contatori per Telemetry

**Contesto:** telemetry.ts usava Set per tracciare frame, crescendo potenzialmente all'infinito.

**Decisione:**
- Sostituire Set con contatori semplici
- yoloProcessedFramesCount
- Incremento atomico per ogni frame
- **Nota:** ballDetectionFramesCount e playerDetectionFramesCount rimossi in Decision 23 (duplicati non usati)

**Rationale:**
- 20 FPS × 60 minuti = 72.000 frame
- Set cresce all'infinito
- Contatori hanno footprint costante

**Conseguenze:**
- Telemetry: contatori invece di Set
- Memory footprint costante
- Performance migliorata

---

## Decision 11: Inizializzazione Async della Queue

**Contesto:** Il costruttore di WorkoutAsyncQueue chiamava loadPending() senza await, creando race condition.

**Decisione:**
- Costruttore reso privato
- Metodo statico async `create()` per inizializzazione
- Flag `initialized` previene enqueue prematuro
- `await createWorkoutQueue()` obbligatorio

**Rationale:**
- Garantisce che loadPending() sia completato prima di accettare eventi
- Previene race condition tra loadPending() e enqueueCritical()
- Pattern factory per controllo lifecycle

**Conseguenze:**
- Inizializzazione esplicita e sicura
- Race condition eliminate
- Chiamanti devono usare await

**⚠️ NON IMPLEMENTATO:**
- In `WorkoutSessionScreen.tsx`, la camera viene attivata PRIMA che la queue sia pronta:
  ```typescript
  setSession(s)
  setIsActive(true)  // Camera ON
  setShotCount(...)
  workoutQueueRef.current = await createWorkoutQueue(...)  // Queue pronta DOPO
  ```
- Per un breve periodo, la camera è attiva ma la queue è null
- Eventi generati in questo intervallo possono essere persi

---

## Decision 12: Global Recovery da Tutte le Sessioni

**Contesto:** PersistentOutbox caricava solo item della sessione corrente, perdendo dati da sessioni precedenti.

**Decisione:**
- `loadAllPending()` carica item da TUTTE le sessioni precedenti
- `loadPending()` carica item della sessione corrente e merge
- WorkoutAsyncQueue chiama entrambi all'inizializzazione
- Sorting per timestamp globale

**Rationale:**
- Recupera eventi persi da crash precedenti
- Una sessione può recuperare eventi di sessioni precedenti
- Garantisce zero data loss across sessioni

**Conseguenze:**
- Recovery automatico di eventi pendenti
- Sessione corrente può completare eventi di sessioni precedenti
- Merge ordinato per timestamp

**⚠️ BUG CRITICO:**
- `WorkoutAsyncQueue.create()` chiama:
  1. `await queue.criticalOutbox.loadAllPendingAndMerge()` - include sessione corrente
  2. `await queue.criticalOutbox.loadPending()` - ricarica sessione corrente
- Senza deduplica per id, questo causa duplicazione degli item nella memory queue
- Gli stessi eventi possono essere processati più volte

---

## Decision 13: Rimozione Limite MAX_OUTBOX_SIZE

**Contesto:** MAX_OUTBOX_SIZE = 100 causava rifiuto di eventi critici quando raggiunto.

**Decisione:**
- Rimozione completa di MAX_OUTBOX_SIZE
- Eventi critici mai rifiutati per dimensione
- Unbounded queue per critical events

**Rationale:**
- Critical events = non perdere dati
- Storage AsyncStorage ha capacità sufficiente
- Rifiuto viola definizione "critical"

**Conseguenze:**
- Nessun overflow per critical events
- Garanzia di accettazione per tutti gli eventi critici
- Memory management affidato a AsyncStorage

---

## Decision 14: Retry Count Persistente

**Contesto:** retryCount era salvato ma non aggiornato durante retry, perdendo stato.

**Decisione:**
- `updateRetryCount()` chiamato prima di ogni tentativo
- Retry count persistito in AsyncStorage
- Recovery conosce stato esatto dopo riavvio
- Backoff esponenziale basato su retry count persistito

**Rationale:**
- Retry deve essere resumable dopo crash
- Evita retry infiniti o prematuri
- Stato persistente per affidabilità

**Conseguenze:**
- Retry count incrementato e persistito
- Recovery riprende dal retry count corretto
- Backoff esponenziale corretto

---

## Decision 15: Shutdown Sicuro

**Contesto:** shutdown() chiamava clear() anche con eventi pendenti, perdendo dati.

**Decisione:**
- `shutdown()` controlla se critical outbox vuoto
- Se vuoto: `clearSession()` (memoria + storage)
- Se pendenti: `clear()` (solo memoria, storage per recovery)
- Log warning se shutdown con eventi pendenti

**Rationale:**
- Non cancellare eventi non consegnati
- Storage deve persistere per recovery
- Memoria può essere pulita

**Conseguenze:**
- Shutdown non perdere dati
- Recovery possibile dopo shutdown
- Logging per situazioni anomale

**⚠️ BUG CRITICO:**
- `shutdown()` chiama `flushAll()` che contiene un loop while:
  ```typescript
  while (this.criticalOutbox.size > 0 || this.telemetry.size > 0) {
    await this.flush(...)
  }
  ```
- Se il backend è offline con critical events pendenti, questo loop può continuare indefinitamente
- Nonostante `flushCriticalOnly(maxAttempts)` esista, `shutdown()` non lo usa direttamente
- L'utente che preme "Fine" con backend offline può rimanere bloccato in `await workoutQueue.shutdown()` senza mai arrivare alla navigation

---

## Decision 16: Separazione clear() da clearSession()

**Contesto:** clear() cancellava sia memoria che storage, pericoloso per recovery.

**Decisione:**
- `clear()` - pulisce solo memory queue
- `clearSession()` - pulisce memory + storage
- `clear()` usato in shutdown con eventi pendenti
- `clearSession()` usato solo quando tutti eventi consegnati

**Rationale:**
- Separazione responsabilità memoria vs storage
- Storage deve persistere per recovery
- Memoria può essere pulita liberamente

**Conseguenze:**
- Semantica chiara per ogni operazione
- Recovery garantito con storage persistente
- Memory management flessibile

---

## Decision 17: API Reali per SESSION_END/CALIBRATION

**Contesto:** SESSION_END e CALIBRATION erano placeholder (console.log), non inviati al backend.

**Decisione:**
- `SESSION_END` chiama API `endWorkoutSession()`
- `CALIBRATION` chiama API `saveCourtCalibration()`
- `SESSION_START` confermato (gestito da creazione sessione)
- Retry con backoff per API calls

**Rationale:**
- Eventi critici devono essere realmente inviati
- Backend deve ricevere conferma sessione
- Calibration deve essere persistita

**Conseguenze:**
- SESSION_END e CALIBRATION realmente critici
- Backend riceve tutti gli eventi
- Retry automatico su fallimento

**⚠️ NON IMPLEMENTATO:**
- Le API esistono e funzionano, ma la UI non le usa attraverso la critical queue
- `CalibrationScreen.tsx` chiama direttamente `await saveCourtCalibration(...)`
- `WorkoutSessionScreen.tsx` chiama direttamente `await endWorkoutSession(...)`
- La funzione nella queue per gestirli esiste (`case 'SESSION_END'`, `case 'CALIBRATION'`) ma il normale flow UI non la utilizza
- Questo significa che non c'è retry automatico se il backend è offline

---

## Decision 18: Eventi Rimangono in Outbox dopo Retry Exhaustion

**Contesto:** Dopo 5 retry falliti, eventi venivano rimossi dall'outbox (persi).

**Decisione:**
- Eventi rimangono in outbox dopo esaurimento retry
- `processCriticalFromOutbox()` break dopo fallimento
- Eventi ritentati in batch successivi
- Rimozione solo su successo API

**Rationale:**
- Retry exhaustion ≠ fallimento permanente
- Network può riprendere dopo retry exhaustion
- Eventi critici non devono essere persi mai

**Conseguenze:**
- Eventi persistono indefinitamente finché non consegnati
- Retry continuo in batch successivi
- Garanzia di consegna a lungo termine

---

## Decision 20: OutboxRecoveryWorker Background

**Contesto:** Eventi pendenti da sessioni precedenti non venivano ritentati automaticamente dopo crash o riavvio.

**Decisione:**
- `OutboxRecoveryWorker` - singleton worker background
- Intervallo configurabile (default 30 secondi)
- Carica item da TUTTE le sessioni precedenti
- Retry con backoff esponenziale (1s, 2s, 4s, 8s, 16s)
- Max 5 retry per evento
- Rimozione solo su successo API
- Avvio/arresto manuale

**Rationale:**
- Recovery automatico senza bloccare sessioni attive
- Worker indipendente non impatta performance sessione corrente
- Garantisce retry continuo di eventi pendenti
- Separazione responsabilità: sessione attiva vs recovery background

**Conseguenze:**
- Eventi pendenti ritentati automaticamente
- Sessione corrente non bloccata da recovery
- Zero data loss a lungo termine
- Recovery continuo finché successo o retry exhaustion

**⚠️ BUG CRITICO:**
- `OutboxRecoveryWorker` usa chiavi AsyncStorage sbagliate:
  - `PersistentOutbox.add()` salva con chiave: `workout_outbox_<id>`
  - `OutboxRecoveryWorker.removeItem()` usa: `await AsyncStorage.removeItem(id)`
  - `OutboxRecoveryWorker.incrementRetryCount()` usa: `await AsyncStorage.setItem(item.id, ...)`
- Questo causa:
  - L'evento viene trovato correttamente
  - Viene inviato con successo
  - Il worker tenta di rimuoverlo con chiave sbagliata
  - L'evento originale rimane nello storage
  - Alla prossima recovery può essere reinviato (duplicazione)

---

## Decision 21: Endpoint Batch per Backend

**Contesto:** Il frontend inviava frame data singolarmente, causando carico HTTP eccessivo.

**Decisione:**
- Endpoint POST /api/workouts/sessions/{sessionId}/frames/batch
- Accetta lista di FrameDataRequest
- Salva tutti i frame in una singola transazione

**Rationale:**
- Riduce richieste HTTP da 20/sec a 1/sec
- Batch più efficiente per il database
- Allineato con architettura queue async

**Conseguenze:**
- Frontend: batch di 20 frame per richiesta
- Backend: transazione singola per batch
- Carico HTTP ridotto del 95%

**⚠️ NON IMPLEMENTATO:**
- Il worker chiama `flush()` immediatamente su ogni `enqueueTelemetry()`
- `telemetry.drain(20)` tende a restituire 1 elemento invece di 20
- Comportamento reale: sample → HTTP batch da 1 → 500ms → sample → HTTP batch da 1
- Il batching da 20 frame non è garantito dall'implementazione
- Il carico HTTP reale è molto più alto del previsto

---

## Decision 22: Configurazione HALF_COURT vs FULL_COURT

**Contesto:** L'applicazione supporta due tipi di campo: HALF_COURT e FULL_COURT, con dimensioni diverse.

**Decisione:**
- `COURT_CONFIG.WIDTH_M: 15.24` (50 feet) - larghezza costante
- `COURT_CONFIG.HEIGHT_M: 28.65` (94 feet) - altezza FULL court
- HALF_COURT dovrebbe avere altezza ~14m
- `courtType` deve essere propagato attraverso il navigation flow
- Homography deve usare dimensioni corrette in base al tipo di campo

**Rationale:**
- Le coordinate campo (courtX, courtY) dipendono dalle dimensioni reali
- Distance from hoop, zone e shot chart richiedono coordinate accurate
- Analytics basati sulla posizione richiedono configurazione corretta

**Conseguenze:**
- FULL_COURT: 15.24 x 28.65 metri
- HALF_COURT: 15.24 x ~14 metri
- Overlay e calibrazione devono adattarsi al tipo di campo

**⚠️ NON IMPLEMENTATO:**
- `COURT_CONFIG.HEIGHT_M` è hardcoded a 28.65m senza configurazione separata per half court
- `CalibrationScreen.tsx` usa sempre `COURT_CONFIG.HEIGHT_M` anche per HALF_COURT
- `courtType` non viene propagato nel navigation flow:
  - `WorkoutSetupScreen.tsx` seleziona `courtType` e lo invia al backend
  - `CalibrationScreen.tsx` riceve `undefined` per `courtType` nei params
  - Fallback a `HALF_COURT` anche se l'utente ha selezionato FULL_COURT

---

## Decision 23: Conversione YOLO/MoveNet ad Async con Schedule Wait Measurement

**Contesto:** L'architettura sincrona precedente (runSync() nel worklet) causava frame processor latency elevata (75-100 ms). Il CPU crop nel worklet bloccava per ~50 ms, e non era possibile misurare la contesa del runtime RN separatamente dal tempo di inferenza.

**Decisione:**
- Convertire YOLO ad async con `scheduleOnRN()` in `useYoloWorker.ts`
- Convertire MoveNet ad async con `scheduleOnRN()` in `useMoveNetWorker.ts`
- Separare `t0` (worklet start) da `tScheduleStart` (post-preparation) per MoveNet
- Calcolare `workletPrepMs = tScheduleStart - t0` per MoveNet
- Calcolare `scheduleWaitMs = tCallbackStart - tScheduleStart` per entrambi i worker
- Aggiungere `perfYoloScheduleWaitTotal` SharedValue in `useShotTracker.ts`
- Aggiungere `perfMoveNetWorkletPrepTotal` e `perfMoveNetScheduleWaitTotal` SharedValue in `useShotTracker.ts`
- Aggiungere `yoloScheduleWaitMs` e `moveNetWorkletPrepMs` a `DiagnosticWindowSnapshot` in `telemetry.ts`
- Aggiornare logging per mostrare breakdown completo:
  - `YOLO DETAIL schedule=Xms resize=Yms run=Zms parse=Ams`
  - `MOVE DETAIL prep=Xms schedule=Yms crop=Zms resize=Ams run=Bms parse=Cms`

**Rationale:**
- L'architettura async permette di misurare la contesa del runtime RN separatamente dal tempo di inferenza
- scheduleOnRN() entra in una coda e attende disponibilità runtime - questo tempo deve essere misurato
- Separare worklet prep da schedule wait permette di identificare se il collo di bottiglia è nella preparazione o nella contesa runtime
- CPU crop spostato su JS thread async riduce frame processor latency
- Misurazione precisa permette di identificare se YOLO runSync() blocca MoveNet scheduleWait

**Conseguenze:**
- Camera FPS migliorata da ~10-14 FPS a 27-30 FPS (target raggiunto)
- Frame latency ridotta da 75-100 ms a 17-32 ms
- YOLO FPS naturale ~4-5 (basato su tempo inferenza async ~40-50ms)
- MoveNet FPS naturale ~3-4 (basato su tempo inferenza async ~200-230ms)
- Schedule wait misurato: 45-134 ms per MoveNet (variabile)
- Worklet prep misurato: ~5 ms per MoveNet
- CPU crop ridotto a ~15 ms (accettabile)
- Nuovo collo di bottiglia identificato: contesa RN runtime
- Breakdown completo disponibile nei log per debugging

**Risultati (post-implementazione):**
- Log mostrano: `CAM fps=29.6 recv=30 proc=28 drop=2 avg=17.0ms max=32.1ms`
- Log mostrano: `MOVE DETAIL prep=4.8ms schedule=77.1ms crop=15.4ms resize=3.9ms run=103.2ms parse=0.4ms total=213.4ms`
- Log mostrano: `YOLO DETAIL schedule=Xms resize=Yms run=Zms parse=Ams`
- Schedule wait variabile (44-134 ms) indica contesa runtime RN
- Frame processor non più collo di bottiglia
- CPU crop non più collo di bottiglia

**Roadmap (basata su nuova misurazione):**
1. Misurare scheduleWaitMs YOLO vs MoveNet per identificare contesa bidirezionale
2. Ridurre trasferimento buffer 640×360×3 (~2.64 MB) eliminando resize intermedio
3. Investigare crop/resize native prima di scheduleOnRN
4. Ottimizzare delegate MoveNet (GPU/NPU se disponibile)
5. Considerare worker thread separati per YOLO/MoveNet

---

## Decision 24: Correzioni Telemetry Structural Bugs

**Contesto:** Il sistema telemetry aveva diversi bug strutturali che causavano metriche inaccurate e duplicazione delle sorgenti FPS.

**Problemi identificati:**
1. **Contatori duplicati non usati:** `ballDetectionFramesCount` e `playerDetectionFramesCount` venivano inizializzati ma mai incrementati, causando sempre 0 in telemetry
2. **Detection rate semantica errata:** Calcolata come `framesWithDetection / framesProcessed` (frame camera) invece di `framesWithDetection / yoloExecuted` (inferenze YOLO)
3. **Sorgenti FPS duplicate:** YOLO worker, ShotTracker e telemetryLogger calcolavano FPS separatamente, causando valori inconsistenti
4. **MoveNet senza hard cap 3 FPS:** Aveva solo single-flight senza throttle temporale
5. **Latest-frame-wins incompleto:** YOLO usava solo flag `hasPendingFrame` senza memorizzare il frame effettivo
6. **Nessun cancellation su unmount:** Inferenze potevano continuare dopo session unmount

**Decisione:**
- **P0 - Rimozione contatori duplicati:** Eliminato `ballDetectionFramesCount` e `playerDetectionFramesCount` da telemetry.ts
- **P0 - Fix detection rate:** Cambiato denominatore da `framesProcessed` a `yoloExecuted` in `getBallDetectionMetrics()` e `getPlayerDetectionMetrics()`
- **P1 - Unica sorgente FPS:** Rimosso `throughputFps` calcolo duplicato da `useYoloWorkerAsync.ts`, mantenuto `telemetryLogger.getYoloPerfMetrics()` come sorgente canonica. Nota: useShotTracker mantiene contatori diagnostici locali (windowThroughputFps) ma non sono considerati source of truth
- **P2 - MoveNet 3 FPS cap:** Aggiunto `MOVENET_TARGET_FPS = 3` con deterministic rate limiting (333ms interval) prima di single-flight check
- **P3 - Latest-frame-wins flag-based:** Implementato flag `hasPendingFrame` worklet-safe. Nota: True latest-frame-wins con frame buffer richiede architettura native queue; implementazione attuale usa flag-based (worklet-safe) a causa di limitazioni scheduleOnRN
- **P4 - Cancellation guard su unmount:** Aggiunto `isMountedRef` a entrambi i worker con cleanup useEffect. Nota: Invalida callback/inferenze non ancora iniziate; le inferenze già in esecuzione non sono interrompibili

**Rationale:**
- Contatori duplicati causavano metriche sempre a 0 (bug concreto)
- Detection rate deve misurare "In quale percentuale delle inferenze YOLO ho trovato una palla?" non "In quale percentuale dei frame camera?"
- Sorgenti FPS multiple causano confusione nei log (es. YOLO=10.8, ShotTracker=3.9, Overlay=4.9). telemetryLogger è la source of truth; contatori diagnostici locali in ShotTracker sono accettabili se chiaramente etichettati
- MoveNet doveva avere un hard cap 3 Hz come specificato (deterministic rate limiting, non adaptive)
- Latest-frame-wins con frame buffer richiede architettura native queue. Implementazione attuale usa flag-based worklet-safe a causa di limitazioni scheduleOnRN (funzioni locali non permesse)
- Inferenze post-session causano overhead e potenziali crash. Cancellation guard previene nuove inferenze dopo unmount, ma non interrompe inferenze già in corso

**Conseguenze:**
- Telemetry: metriche semanticamente corrette (ballFrames, playerFrames non più 0)
- Detection rate: calcolato correttamente come % di inferenze YOLO con detection
- FPS: telemetryLogger è sorgente canonica, valori consistenti. ShotTracker mantiene contatori diagnostici locali
- MoveNet: throughput limitato a ~3 FPS con deterministic rate limiting + single-flight
- YOLO: latest-frame-wins flag-based (worklet-safe). True buffer-based richiede architettura native queue
- Lifecycle: nuove inferenze non iniziate dopo unmount (cancellation guard). Inferenze già in esecuzione possono completare

**Risultati attesi (da verificare con runtime benchmark):**
- Log più leggibili e semanticamente corretti
- CAM target 30 FPS, observed ~25 FPS, best ~29-30 FPS
- YOLO ≤10 FPS (deterministic rate limiting)
- MoveNet ≤3 FPS (deterministic rate limiting)
- YOLO: executedFrames=N, framesWithBall=M, ballRate=M/N (non più 0 se modello produce detection)
- YOLO: framesWithPlayer=P, playerRate=P/N (non più 0 se modello produce detection)
- MoveNet: executedFrames=K, throughput≈3 FPS
- camera avg onFrame: attuale ~27-30 ms (future target <10 ms con native crop optimization)
- **Nota P3:** Latest-frame-wins implementato come flag-based worklet-safe; true buffer-based richiede architettura native queue

**Nota importante:** P0-P3 implementati e verificati staticamente. P4 implementato come cancellation guard per callback/inferenze non ancora iniziate; le inferenze già in esecuzione non sono interrompibili. Il prossimo runtime benchmark deve verificare detection-rate, YOLO ≤10 FPS, MoveNet ≤3 FPS e assenza di post-unmount callback execution.

**Problemi non risolti da Decision 24:**
- Qualità player bbox (PLAYER_CONFIDENCE_THRESH = 0.005 estremamente permissivo)
- False-positive/suspicious rate
- Float32 normalizzato vs modello uint8
- Schedule wait YOLO/MoveNet (contesa RN runtime)
- ~2.64 MB di buffer intermedio
- CPU crop su JS thread
- Delegate MoveNet
- Camera che resta intorno a ~25 FPS
- Vera cancellazione di un'inferenza già partita (richiederebbe worklet-safe SharedValue)

**Roadmap post-Decision 24 (YOLO FPS benchmark):**
- **Step 1 COMPLETATO:** Verificato rate limiter YOLO - pending frame non bypassa throttle. Quando YOLO termina, pulisce solo il flag `hasPendingFrame` senza resubmittere il frame. Il prossimo frame dalla camera passa sempre attraverso `submitFrame`, che applica il throttle all'inizio.
- **Step 2 COMPLETATO:** Cambiato YOLO_TARGET_FPS da 10 a 15 FPS per benchmark test.
- **Step 3 IN CORSO:** Eseguire benchmark test con configurazione:
  - Camera: 30 FPS target
  - YOLO: 15 FPS target (up from 10 FPS baseline)
  - MoveNet: 3 FPS target (invariato)
  - Tracking: ogni frame (invariato)
- **Metriche da misurare:**
  - camera throughput
  - YOLO throughput (actual, non theoretical)
  - YOLO schedule wait
  - YOLO latency
  - MoveNet throughput
  - frame drops
- **Criterio di successo:**
  - YOLO FPS ↑, camera FPS ≈ 30, MoveNet FPS ≈ 3, schedule wait non esplode
  - 15 FPS target → ~14-15 FPS reale con camera ~30 e MoveNet ~3 = ottimo
  - Se schedule wait esplode o camera collassa, tornare a 10 FPS

---

## Decision 25: VisionPipelineAdapter Pattern

**Contesto:** Il Runtime deve controllare la vision pipeline per coordinare il lifecycle della sessione, ma la vision pipeline è implementata come hook React (useWorkoutVisionPipeline) che non può essere direttamente istanziato dal Runtime puro.

**Decisione:**
- Creare `VisionPipelineAdapter` che implementa `IVisionPipeline`
- Adapter wrappa le funzioni `setIsActive(true/false)` dell'hook React
- Screen crea l'adapter e lo passa al Runtime via `setVisionPipeline()`
- Runtime chiama `visionPipeline.start()/stop()` per controllare la vision pipeline
- Runtime lifecycle (start/pause/resume/stop) controlla la vision pipeline
- Pattern: React Hook → Adapter → IVisionPipeline Interface → Runtime

**Rationale:**
- Il Runtime non può dipendere da React Native/Skia (principio architetturale)
- L'adapter permette al Runtime di controllare la vision pipeline senza dipendenze React
- Separazione chiara: Screen possiede l'hook, Runtime coordina il lifecycle
- Il pattern adapter è reversibile e testabile

**Conseguenze:**
- Runtime può coordinare effettivamente la vision pipeline
- Vision pipeline controllata da Runtime.start/pause/resume/stop
- Screen possiede ancora l'hook ma delega il controllo al Runtime
- Architettura più pulita con separazione responsabilità

**Stato:** ✅ IMPLEMENTATO
- `VisionPipelineAdapter.ts` creato
- Collegato a Runtime in WorkoutSessionScreen
- Runtime controlla vision pipeline tramite lifecycle

---

## Decision 26: WorkoutSessionRuntime Ownership Transfer

**Contesto:** Il WorkoutSessionRuntime era istanziato ma non possedeva i sottosistemi critici (Vision, Tracking, Shot Detection). La Screen gestiva ancora il lifecycle di questi componenti, causando warning e accoppiamento inappropriato. Inoltre, c'era un problema di timing: runtime.start() veniva chiamato PRIMA che i sottosistemi fossero connessi.

**Problemi identificati:**
1. **Ownership non chiaro:** TrackingEngine, VisionPipeline e ShotDetectionEngine erano gestiti dalla Screen, non dal Runtime
2. **Timing di connessione:** runtime.start() veniva chiamato prima che i sottosistemi fossero connessi
3. **Anti-pattern ShotDetectionUIAdapter:** Classe che usava useSharedValue (hook React) all'interno di una classe
4. **Double ownership potenziale:** ShotDetectionEngine poteva essere istanziato sia da TrackingEngine che dal Runtime
5. **useEffect ripetuti:** Connessioni ripetute causate da dependency array non corretto

**Decisione:**
- **P0 - Transfer ownership al Runtime:** 
  - Vision: collegata via VisionPipelineAdapter (già implementato in Decision 25)
  - Tracking: collegata via setTrackingEngine()
  - Shot Detection: collegata via TrackingEngine.getShotDetectionEngine() per evitare double ownership
  - TelemetrySampler: collegato e utilizzato dal Runtime
  - WorkoutQueue: già collegato (ownership intermedio - Screen crea, Runtime usa)
- **P0 - Fix timing connessioni:** 
  - Aggiungere state flags (trackingConnected, visionConnected)
  - Aggiungere ref flags (trackingConnectedRef, visionConnectedRef) per evitare connessioni ripetute
  - runtime.start() chiamato SOLO dopo che tutti i sottosistemi sono connessi
  - useEffect per TrackingEngine connection con check trackingConnectedRef
  - useEffect per VisionPipelineAdapter connection con check visionConnectedRef
- **P1 - Rimozione ShotDetectionUIAdapter:** 
  - Rimuovere file ShotDetectionUIAdapter.ts (anti-pattern)
  - Rimuovere export da tracking/index.ts
- **P2 - Test state machine:** 
  - Creare WorkoutSessionRuntime.test.ts
  - Test tutte le transizioni di stato (IDLE → STARTING → ACTIVE → PAUSED → STOPPING → SYNCING → COMPLETED → ERROR)
  - Test transizioni illegali
  - Test interazione con sottosistemi

**Rationale:**
- Il Runtime deve coordinare il lifecycle di tutti i sottosistemi per garantire consistenza
- I sottosistemi devono essere connessi PRIMA che il Runtime inizi per evitare warning
- ShotDetectionUIAdapter è un anti-pattern (useSharedValue in class) e non usato
- Double ownership di ShotDetectionEngine causa confusione e potenziali bug
- Le ref flags prevengono connessioni ripetute causate da dependency array non corretto
- I test garantiscono che la state machine funzioni come previsto

**Conseguenze:**
- Runtime ora possiede Vision, Tracking e Shot Detection
- Tutti i sottosistemi connessi PRIMA di runtime.start()
- Nessun warning di sottosistemi mancanti
- ShotDetectionEngine ottenuto da TrackingEngine (no double ownership)
- Nessuna connessione ripetuta (log singoli)
- ShotDetectionUIAdapter rimosso (codice più pulito)
- Test state machine completi implementati

**Risultati (post-implementazione):**
- Log mostrano connessioni singole (non più ripetute):
  - `TrackingEngine connected to runtime` - appare solo una volta
  - `ShotDetectionEngine connected to runtime` - appare solo una volta
  - `VisionPipelineAdapter connected to runtime` - appare solo una volta
- Runtime state machine corretta: IDLE → STARTING → ACTIVE → STOPPING → SYNCING → COMPLETED
- Performance pipeline vision normale:
  - YOLO: 6-25fps (normalmente 6-7fps)
  - MoveNet: 2.9-3.9fps
  - Camera: 18-26fps
  - Detection rate: 98%+

**Stato:** ✅ IMPLEMENTATO
- VisionPipelineAdapter collegato (Decision 25)
- TrackingEngine collegato via setTrackingEngine()
- ShotDetectionEngine collegato via getShotDetectionEngine()
- Timing fix con state flags e ref flags
- ShotDetectionUIAdapter rimosso
- WorkoutSessionRuntime.test.ts creato con test state machine completi
- Lifecycle responsibilities migrate al Runtime (handlePauseResume, handleEndSession, handleManualShot)

---

## Decision 27: Vision Migration Plan

**Contesto:** useShotTracker.ts è un file legacy di 1.447 righe che contiene tutta la logica di vision (YOLO, MoveNet, player crop, telemetry). Il Runtime attualmente controlla il lifecycle ma non processa i frame. L'architettura attuale è:

```
Camera → useShotTracker (worklet) → callbacks → Screen → TrackingEngine
```

L'obiettivo è:

```
Camera → VisionEngine → Runtime.processFrame() → TrackingEngine → ShotDetectionEngine
```

**Problemi identificati:**
1. **useShotTracker è worklet-heavy:** La logica di elaborazione frame è nel worklet onFrame, che non può essere facilmente estratta in una classe pura
2. **YOLO/MoveNet workers sono hook React:** useYoloWorker e useMoveNetWorker sono hook che gestiscono SharedValues e worklet
3. **Telemetry è integrata nel worklet:** I contatori di performance sono SharedValues aggiornati nel worklet
4. **Frame processor è accoppiato a React Native Vision Camera:** useFrameOutput è specifico per react-native-vision-camera

**Decisione:**
- **Fase 1 - Infrastruttura (COMPLETATO):**
  - Creare IVisionEngine interface
  - Creare VisionEngine placeholder class
  - Aggiungere Runtime.processFrame() per orchestrare Vision → Tracking → Shot
  - Creare VisionEngineAdapter placeholder
- **Fase 2 - Estrazione YOLO/MoveNet (COMPLETATO):**
  - Estrarre logica YOLO da yoloParserFloat16.ts a YoloDetector (classe pura worklet-safe)
  - Estrarre logica MoveNet da poseParser.ts a MoveNetPoseEstimator (classe pura worklet-safe)
  - Creare VisionEngine.ts in vision/engine/ per orchestrazione YOLO + MoveNet
  - Integrare YoloDetector in useYoloWorker e useYoloWorkerAsync
  - Integrare MoveNetPoseEstimator in useMoveNetWorker
  - Rimuovere codice legacy (poseParser.ts, yoloParserFloat16.ts, VisionEngine.ts placeholder)
  - Aggiornare test per usare YoloDetector
  - Semplificare VisionEngineAdapter per forward parsed results
  - Nota: L'inference rimane nei worker React hooks perché dipende da react-native-fast-tflite e react-native-vision-camera-resizer. Le classi pure gestiscono solo il parsing, non l'inference.
- **Fase 3 - Integrazione VisionEngine (COMPLETATO):**
  - Decisione architetturale: Workers restituiscono parsed results (non raw output)
  - VisionEngine accetta parsed results con fallback per raw outputs
  - Workers fanno inference + parsing (dipendenze React Native)
  - VisionEngine orchestrazione con parsed results (no duplicate parsing)
  - VisionEngineAdapter istanzia VisionEngine e gli passa parsed results
  - VisionEngineAdapter aggiunto metodo getCurrentResults() per esporre dati correnti
  - Callbacks (handleBallDetection, handlePoseResult, handleRimDetection) aggiornati per feed VisionEngineAdapter
  - Conversione tipo: vision/types → VisionEngine.types (pose keypoints oggetto → array + confidence)
- **Fase 4 - Migrazione Runtime (COMPLETATO):**
  - VisionEngineAdapter istanziato in WorkoutSessionScreen
  - Collegato a Runtime via setVisionEngine()
  - Runtime.processFrame() chiamato dai callbacks quando Runtime è ACTIVE
  - Flag useRuntimeProcessingRef per toggle tra path Runtime e legacy
  - Aggiunto onTrackingStateUpdate callback a SessionCallbacks
  - Runtime.processFrame() chiama callback dopo TrackingEngine.processFrame()
  - Aggiunto updateSharedValuesFromState() a useTrackingEngine
  - SharedValues aggiornati da callback Runtime per Skia overlay
  - Path legacy esiste come fallback (skippato quando Runtime è attivo)
  - Fix double ShotDetectionEngine call (rimosso da Runtime.processFrame())
  - Fix TypeScript type mismatches (BallDetection senza player, PoseResult conversion)
  - **Fase 4.1 - Fix VisionEngineAdapter partial update:** updateParsedResults() ora aggiorna solo campi non-null per preservare risultati da altri callbacks
  - **Fase 4.2 - Unificare trigger Runtime.processFrame():** aggiunto debounce 50ms per evitare chiamate duplicate per lo stesso frame logico
  - **Fase 4.3 - Disattivare legacy Shot Detection:** handleShotEvent skip quando Runtime è attivo, logica screenshot spostata in onShotDetected callback
- **Fase 5 - Cleanup (PENDING):**
  - Rimuovere path legacy dai callbacks (tracking.processFrame diretto)
  - Rimuovere useShotTracker.ts legacy
  - Rimuovere VisionEngineAdapter (se non più necessario)
  - Aggiornare test

**Rationale:**
- Estrazione incrementale riduce rischio di regressione
- Mantenere worklet-safe è critico per performance
- SharedValues rimangono come bridge React → worklet
- VisionEngine diventa il centro di elaborazione vision puro
- Workers restituiscono parsed results per rispettare dipendenze React Native
- Path legacy mantenuto come fallback durante transizione

**Conseguenze:**
- VisionEngine è la sorgente unica di detection (ball, player, rim, pose)
- Runtime.processFrame() è il PRIMARY path quando VisionEngine è connesso
- Path legacy esiste come fallback (skippato quando Runtime è attivo)
- useShotTracker.ts ridotto a wrapper di workers (ShotDetector.ts rimosso completamente)
- Architettura più pulita con separazione responsabilità
- Shot detection non duplicata (solo TrackingEngine chiama ShotDetectionEngine)
- PlayerDetection ora fluisce nel nuovo percorso Runtime
- PlayerDetection integrato via TrackingEngine.processFrame() (ottavo parametro)
- Test TrackingEngine.test.ts per PlayerDetection aggiunti
- Kalman filter ottimizzato per massima reattività

**Stato:** ✅ FASE 3, 4, 5 & 6 COMPLETATE (CON CORREZIONI 4.1-4.4)
- Fase 1: ✅ COMPLETATO (IVisionEngine, VisionEngine, Runtime.processFrame, VisionEngineAdapter)
- Fase 2: ✅ COMPLETATO (Estrazione YOLO/MoveNet in classi pure worklet-safe + integrazione worker + rimozione legacy)
- Fase 3: ✅ COMPLETATO (VisionEngine integration - parsed results path, callbacks aggiornati, type conversion)
- Fase 4: ✅ COMPLETATO (Runtime.processFrame() attivo, callback onTrackingStateUpdate, SharedValues sync, double call fix)
  - Fase 4.1: ✅ COMPLETATO (VisionEngineAdapter partial update - non cancella altri risultati)
  - Fase 4.2: ✅ COMPLETATO (Runtime.processFrame() debounce 50ms - evita chiamate duplicate)
  - Fase 4.3: ✅ COMPLETATO (Legacy Shot Detection disattivata - single source of truth shot events)
  - Fase 4.4: ✅ COMPLETATO (PlayerDetection integrato nel nuovo percorso - onPlayerDetection callback)
- Fase 5: ✅ COMPLETATO (Legacy cleanup - ShotDetector.ts rimosso completamente, handleShotEvent rimosso)
- Fase 6: ✅ COMPLETATO (test PlayerDetection aggiunti, Kalman filter ottimizzato)

---

## Decision 28: Performance Audit Completato

**Contesto:** L'obiettivo era analizzare sistematicamente la performance della pipeline vision per capire:
1. Il breakdown dettagliato dei tempi di schedule wait per YOLO e MoveNet (pipeline A→F)
2. Perché il ramo predizione del filtro Kalman non viene utilizzato (prediction=0)
3. Se è necessario il tuning dei parametri Kalman
4. Se è necessario ottimizzare il modello/delegate/frequenza MoveNet

**Decisione:**
- Aggiungere telemetry dettagliata con breakdown A→F per YOLO e MoveNet:
  - Worklet prep → scheduleOnRN → callback → preprocess → inference → postprocess
  - Calcolo percentili P50/P95/P99 per schedule wait
  - Arrays di timing in telemetry.ts per ogni fase
  - SharedValues per aggregare metriche nel worklet
  - Calcolo percentili su JS thread (non worklet) per evitare errori runtime
- Verificare il flusso del filtro Kalman:
  - Aggiungere logging diagnostico in BallTrackingEngine.predict()
  - Aggiungere logging diagnostico in TrackingEngine.processFrame()
  - Tracciare quando il ramo prediction viene esercitato
- Analizzare i risultati della telemetry e determinare se è necessario ulteriore tuning

**Rationale:**
- La telemetry A→F con percentili permette di identificare quale fase della pipeline è il collo di bottiglia
- Separare schedule wait da inference time è critico per capire se il problema è la contesa RN o il modello
- Il filtro Kalman deve essere verificato prima di qualsiasi tuning dei parametri
- L'ottimizzazione deve essere guidata da dati, non da ipotesi

**Conseguenze:**
- Telemetry A→F implementata per YOLO e MoveNet con P50/P95/P99
- Logging diagnostico aggiunto per Kalman filter e TrackingEngine
- TypeScript errors corretti (percentili mancanti, duplicati)
- Runtime error corretto (calcolo percentili su JS thread invece di worklet)
- Logging diagnostico rimosso dopo analisi completata

**Risultati dell'audit:**

**Schedule Wait Analysis:**
- YOLO Pipeline:
  - Worklet prep: 0ms
  - Schedule wait: P50=44.4ms, P95=93.3ms, P99=119.7ms
  - JS preprocessing: 0ms
  - Inference: 89.9ms avg
  - Postprocess: 0ms
  - **Schedule wait è ~40-50% della latenza totale**

- MoveNet Pipeline:
  - Worklet prep: 6-12ms avg
  - Schedule wait: P50=75.5ms, P95=161.0ms, P99=185.3ms
  - Crop: 8-9ms avg
  - Quantization: 12ms avg
  - Inference: 105-155ms avg
  - Postprocess: 0.1ms avg
  - **Schedule wait è ~40-60% della latenza totale**

**Kalman Filter Analysis:**
- Prediction count = 0 in tutti i log
- Spiegazione: YOLO rileva la palla nel 100% dei frame
- Il ramo prediction `!ballDetection && this.state.ballPosition && this.lastFrameTs > 0` non viene mai esercitato
- Questo è positivo: YOLO detection è estremamente affidabile
- Il filtro Kalman funziona correttamente come fallback (non richiede tuning parametri)

**Conclusioni:**
- Schedule wait è il principale collo di bottiglia della latenza della pipeline (40-60%)
- La telemetria misura quanto tempo passa prima dell'esecuzione della callback RN, ma non identifica ancora quale attività stia occupando il thread durante quel periodo
- Kalman filter comportamento corretto come fallback (non richiede tuning px/py/mx/my)
- Telemetry A→F con P50/P95/P99 sufficiente per monitorare schedule wait nel tempo
- Nessun tuning aggressivo richiesto al momento

**Problemi risolti:**
- ✅ Kalman prediction=0 spiegato (YOLO detection 100% - ramo prediction non esercitato)
- ✅ Kalman filter comportamento corretto come fallback (non richiede tuning px/py/mx/my)
- ✅ Telemetry A→F con P50/P95/P99 sufficiente per monitorare schedule wait nel tempo
- ✅ Schedule wait identificato come principale area performance (non nascosto in latenza generica)

**Problemi aperti (non richiedono azione immediata):**
- Indagare causa specifica del schedule wait (chi occupa il thread RN per 75-185ms MoveNet e 44-120ms YOLO) - solo se necessario
- Ottimizzare delegate MoveNet - solo se necessario
- Ridurre buffer intermedio 640×360×3 (~2.64 MB) - solo se necessario

**Stato:** ✅ COMPLETATO
- Audit performance completato
- Sistema stabile e misurato
- Schedule wait monitorato con P50/P95/P99
- Kalman filter funzionante come fallback
- Ottimizzazioni future solo se necessario

---

## Decision 29: Disabilitazione useShotTracker Legacy Quando Runtime è Attivo

**⚠️ REVERTED / SUPERSEDED BY LEGACY VISION REMOVAL**

**Contesto:** Quando WorkoutSessionRuntime è attivo, useShotTracker continua a eseguire YOLO/MoveNet ogni frame, creando lavoro duplicato. L'architettura attuale è:

```
Camera
  │
  ├── VisionEngineAdapter → YOLO/MoveNet (Runtime path)
  │
  ├── Runtime → TrackingEngine
  │
  └── useShotTracker → YOLO/MoveNet (legacy path)
             ↓
       lavoro duplicato
```

Questo causa:
- Doppia esecuzione YOLO/MoveNet per ogni frame
- Più lavoro JS/RN
- Più callback
- Più contention
- Più CPU
- Schedule wait più alto

**Decisione:**
- Aggiungere flag `runtimeActive` a `useShotTracker` (default false)
- Aggiungere check in `onFrame` worklet: se `runtimeActive` è true, dispose frame e return immediatamente
- Aggiornare `useCameraPipeline` per passare `runtimeActive` flag
- Aggiornare `useWorkoutVisionPipeline` per passare `runtimeActive` flag
- Aggiornare `WorkoutSessionScreen` per passare `runtimeRef.current?.state === 'ACTIVE'`

**Rationale:**
- Quando Runtime è attivo, VisionEngineAdapter gestisce YOLO/MoveNet execution
- useShotTracker non è più authoritative per il risultato quando Runtime è attivo
- Disabilitare useShotTracker elimina il lavoro duplicato
- Riduce schedule wait eliminando callback RN duplicati
- Mantieni useShotTracker come fallback per quando Runtime non è attivo

**Conseguenze:**
- Quando Runtime è ACTIVE: useShotTracker disabilitato, solo VisionEngineAdapter esegue YOLO/MoveNet
- Quando Runtime non è ACTIVE: useShotTracker attivo, mantiene comportamento legacy
- Meno lavoro JS/RN quando Runtime è attivo
- Meno callback RN
- Meno contention
- Potenziale riduzione schedule wait (da verificare con test)

**Risultati attesi (da verificare con runtime test):**
- Schedule wait ridotto (meno callback RN in competizione)
- CPU ridotta (solo una esecuzione YOLO/MoveNet per frame)
- FPS camera migliorato (meno frame processor overhead)
- Comportamento identico quando Runtime non è attivo

**Stato:** ✅ REVERTATA
- Flag `runtimeActive` rimosso dal frame processor in useShotTracker
- Il parametro runtimeActive esiste ancora nella firma per compatibilità API, ma non viene usato nel frame processor
- Pipeline Vision continua a funzionare anche quando Runtime è ACTIVE
- **Motivo revert:** VisionEngineAdapter non esegue YOLO/MoveNet, è solo un adapter che riceve risultati dai worker. Spegnere useShotTracker spegneva l'intera pipeline Vision.
- **Bug semantico aggiuntivo corretto:** VisionEngineAdapter.updateParsedResults() ora distingue undefined vs null:
  - undefined = non aggiornare questo canale (preserva valore precedente)
  - null = aggiorna canale: detection persa
  - object = aggiorna canale: detection presente
- Tutte le chiamate da WorkoutSessionScreen aggiornate per usare undefined per canali non aggiornati

---

## Decision 30: Correzione Semantica VisionEngineAdapter (Undefined vs Null)

**Contesto:** VisionEngineAdapter.updateParsedResults() aveva una semantica errata dove `null` significava "non aggiornare questo canale" invece di "detection persa". Le chiamate dai callbacks (handlePoseResult, handleBallDetection, handleRimDetection, handlePlayerDetection) passavano `null` per i canali non aggiornati, causando:
- Quando Pose arriva: ball=null, pose=P → ball viene cancellato anche se YOLO aveva rilevato la palla
- Quando Ball arriva: ball=B, pose=null → pose viene cancellato anche se MoveNet aveva rilevato la pose
- Stale detection data persisteva nell'Adapter
- TrackingEngine non vedeva correttamente l'assenza di detection per attivare Kalman prediction

**Problema identificato:**
Due semantiche diverse erano confuse:
1. `null` come "non sto aggiornando questo canale" (usato nelle chiamate callbacks)
2. `null` come "detection persa" (richiesto per Kalman prediction)

**Decisione:**
- Distinguere `undefined` da `null` in VisionEngineAdapter.updateParsedResults()
- `undefined` = non aggiornare questo canale (preserva valore precedente)
- `null` = aggiorna canale: detection persa
- `object` = aggiorna canale: detection presente
- Aggiornare firma metodo: parametri ora `| null | undefined` invece di solo `| null`
- Aggiornare logica: controlli `if (ball !== undefined)` invece di `if (ball !== null)`
- Aggiornare tutte le chiamate da WorkoutSessionScreen:
  - handlePoseResult: passa undefined per ball/player/rim
  - handleRimDetection: passa undefined per ball/player/pose
  - handlePlayerDetection: passa undefined per ball/rim/pose
  - handleBallDetection: passa undefined per player/pose

**Rationale:**
- Callbacks diversi (Pose, Ball, Rim, Player) arrivano a frequenze diverse
- Ogni callback deve aggiornare solo il proprio canale senza cancellare gli altri
- TrackingEngine deve vedere correttamente "detection persa" (null) per attivare Kalman prediction
- La distinzione undefined/null permette partial update semanticamente corretto

**Conseguenze:**
- Quando YOLO perde la palla e passa null, Runtime riceve correttamente "detection persa"
- Pose/Player/Rim non vengono cancellati quando Ball arriva
- Ball non viene cancellato quando Pose arriva
- Kalman prediction può essere attivato correttamente quando detection è persa
- Semantica consistente in tutto il pipeline Vision

**Risultati attesi:**
- TrackingEngine vede correttamente assenza detection per attivare Kalman fallback
- Nessuna cancellazione accidentale di detection da altri callbacks
- Comportamento deterministico quando YOLO perde deliberatamente la palla per alcuni frame

**Stato:** ✅ COMPLETATO
- VisionEngineAdapter.updateParsedResults() aggiornato con undefined/null distinction
- Tutte le chiamate da WorkoutSessionScreen aggiornate per usare undefined
- Documentazione aggiornata (ARCHITECTURE.md, VISION_PERFORMANCE.md, REFACTORING_PROGRESS.md)

---

## Decision 31: MoveNet Bbox Current Detection (Strict Current Policy)

**Contesto:** MoveNet eseguiva con bbox persistente (TTL 750ms) anche quando YOLO non produceva nuove detection player. Questo causava esecuzioni MoveNet inutili con bbox stale, violando il requisito funzionale "MoveNet deve lavorare solo quando esiste una detection player valida".

**Problema identificato:**
- YOLO player detected=65, ma MoveNet eseguiva a 3-4 FPS
- usingLastBbox=349 > detected=412 indicava uso massiccio di bbox vecchie
- PlayerCropManager manteneva bbox per 750ms TTL
- useShotTracker manteneva player per 2000ms TTL
- MoveNet riceveva bbox persistente e eseguiva inferenza inutile

**Decisione:**
- MoveNet richiede bbox corrente (non stale/persistente)
- Condizione aggiornata in useShotTracker: `!trackedBbox.isUsingLastBbox`
- MoveNet esegue solo quando YOLO produce detection player nel frame corrente
- Tracking può continuare a usare bbox persistente (separazione architetturale)
- Nessun cambio TTL (750ms PlayerCrop, 2000ms useShotTracker, 1000ms PlayerTracking)

**Rationale:**
- Requisito funzionale: MoveNet solo con detection player corrente
- Separazione responsabilità: Tracking può persistere, MoveNet no
- Elimina inferenze inutili quando player non rilevato correntemente
- Costo MoveNet eliminato quando non c'è player valido (0 FPS vs 3-4 FPS)
- Architettura corretta: YOLO detection → current bbox → MoveNet

**Conseguenze:**
- MoveNet FPS scende drasticamente quando player detection rate è basso
- MoveNet esegue solo con bbox corrente (no bbox persistente)
- Tracking continua a ricevere aggiornamenti con bbox persistente (intenzionale)
- usingLastBbox counter riflette solo tracking, non esecuzioni MoveNet
- Costo inferenza MoveNet eliminato quando player non rilevato

**Risultati attesi:**
- MoveNet exec=0 quando player non rilevato correntemente
- Tracking può continuare con bbox persistente (se TTL intenzionale)
- Separazione chiara: tracking persistence vs MoveNet execution
- Performance migliorata: niente inferenze MoveNet inutili

**Stato:** ✅ COMPLETATO
- useShotTracker:855-895 aggiornato con `!trackedBbox.isUsingLastBbox`
- MoveNet non esegue quando bbox persistente
- Tracking può continuare con bbox persistente
- Documentazione aggiornata (ARCHITECTURE.md, VISION_PERFORMANCE.md)

---

## Decision 32: Player Stability Threshold Correction + Granular Telemetry

**Contesto:**
1. Player stability metric usava threshold errato (30 in normalized space = 3000% del frame)
2. [BBOX][STABILITY] telemetry era per ball, non player
3. usingLastBbox alto (349) vs YOLO detections basse (65) richiedeva analisi granulare

**Problemi identificati:**
1. telemetry.ts:886 - `jumps.filter(j => j < 30)` - threshold completamente errato in normalized space
2. getBboxStabilityMetrics() calcola ball stability, non player stability
3. Impossibile distinguere tracking corrente vs tracking persistente
4. Distribuzione età bbox non misurata

**Decisione:**
1. Correzione threshold player stability: 30 → 0.02 (2% del frame, allineato con getBboxStabilityMetrics)
2. Aggiunta telemetria granulare player flow:
   - playerTrackingCurrent - tracking con bbox corrente
   - playerTrackingLastBbox - tracking con bbox persistente
   - playerMoveNetExecutions - esecuzioni MoveNet
   - playerBboxAgeBuckets - distribuzione età bbox (0, 1-100, 100-250, 250-500, 500-750, expired ms)
3. Nuovo log [PLAYER][FLOW] con percentili età
4. Nuovo log [PLAYER][AGE_BUCKETS] per distribuzione

**Rationale:**
- Threshold 0.02 corretto per normalized space (2% del frame)
- Telemetria granulare permette distinguere tracking corrente vs persistente
- Bucket età permette analisi distribuzione TTL
- Separazione chiara: YOLO detections → tracking current → tracking last → MoveNet executions
- Dati per decisione futura su TTL (750ms, 2000ms, 1000ms)

**Conseguenze:**
- Player stability metric ora affidabile
- [BBOX][STABILITY] identificato come ball stability
- Telemetria granulare permette analisi dettagliata player flow
- Possibilità di decidere se modificare TTL basata su dati reali

**Risultati attesi:**
- Log: [PLAYER][FLOW] yolo=65 current=65 last=290 ageP50=180ms ageP95=640ms ageMax=748ms trackingCurrent=65 trackingLast=290 moveNet=0
- Log: [PLAYER][AGE_BUCKETS] age0=65 age1to100=120 age100to250=80 age250to500=50 age500to750=40 expired=0
- Dati per decidere se modificare TTL

**Stato:** ✅ COMPLETATO
- telemetry.ts:886 threshold corretto da 30 a 0.02
- telemetry.ts:254-272 contatori granulari aggiunti
- telemetry.ts:706-776 metodi granulari aggiunti
- useShotTracker:217-220 SharedValues granulari aggiunti
- useShotTracker:876-877, 892-893 logging granulare aggiunto
- useShotTracker:512-545 callback aggiornato
- Documentazione aggiornata (ARCHITECTURE.md, VISION_PERFORMANCE.md)
